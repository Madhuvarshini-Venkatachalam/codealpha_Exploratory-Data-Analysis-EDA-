export type ColumnType = 'numeric' | 'categorical' | 'datetime' | 'boolean';

export interface ColumnMetadata {
  name: string;
  type: ColumnType;
  missingCount: number;
  missingPercentage: number;
  uniqueCount: number;
  uniqueValues: string[];
  memoryUsageBytes: number;
  
  // Numeric-specific stats
  mean?: number;
  median?: number;
  min?: number;
  max?: number;
  stdDev?: number;
  q1?: number;
  q3?: number;
  iqr?: number;
  outlierCount?: number;
  outliers?: number[];
}

export interface CorrelationCell {
  col1: string;
  col2: string;
  value: number;
}

export interface DatasetSummary {
  fileName: string;
  fileSize: number;
  rowCount: number;
  columnCount: number;
  duplicateCount: number;
  totalMemoryBytes: number;
  columns: ColumnMetadata[];
  sampleRows: Record<string, any>[];
  allRows: Record<string, any>[]; // Keep all rows for interactive filtering
  correlationMatrix: CorrelationCell[];
}

export interface FilterCondition {
  columnName: string;
  operator: 'equals' | 'contains' | 'greater_than' | 'less_than' | 'not_empty';
  value: string;
}

export interface BusinessQuestion {
  question: string;
  description: string;
  category: string;
}

export interface AIInsights {
  questions: BusinessQuestion[];
  conclusions: string[];
  recommendations: string[];
  chartInsights: Record<string, string>; // chartKey -> insight text
}
