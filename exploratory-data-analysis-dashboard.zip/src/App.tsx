import React, { useState, useMemo, useEffect } from 'react';
import Papa from 'papaparse';
import { motion, AnimatePresence } from 'motion/react';
import * as XLSX from 'xlsx';
import { ColumnMetadata, DatasetSummary, FilterCondition, BusinessQuestion, AIInsights } from './types';
import { analyzeDataset } from './utils/analysis';
import GlassCard from './components/GlassCard';
import DataOverview from './components/DataOverview';
import StatsSummary from './components/StatsSummary';
import AdvancedAnalytics from './components/AdvancedAnalytics';
import Visualizations from './components/Visualizations';
import AiRecommendations from './components/AiRecommendations';
import ReportGenerator from './components/ReportGenerator';
import {
  UploadCloud, Sparkles, RefreshCw, Moon, Sun, Table, BarChart2, TrendingUp, HelpCircle, FileText, LayoutDashboard, Database, Sliders, Play, ChevronRight, X, Image
} from 'lucide-react';

const SAMPLE_DATASET = [
  { Date: "2026-01-01", Country: "USA", Segment: "Enterprise", Category: "Cloud Infrastructure", Sales: 42500, MarginPercent: 68, CustomerRating: 4.5, GrowthRate: 12 },
  { Date: "2026-01-12", Country: "Canada", Segment: "Mid-Market", Category: "SaaS Software", Sales: 28400, MarginPercent: 82, CustomerRating: 4.1, GrowthRate: 8 },
  { Date: "2026-01-25", Country: "Germany", Segment: "SMB", Category: "Consulting Services", Sales: 15400, MarginPercent: 45, CustomerRating: 4.7, GrowthRate: 15 },
  { Date: "2026-02-05", Country: "USA", Segment: "Enterprise", Category: "SaaS Software", Sales: 48200, MarginPercent: 80, CustomerRating: 3.9, GrowthRate: 18 },
  { Date: "2026-02-18", Country: "Germany", Segment: "Mid-Market", Category: "Cloud Infrastructure", Sales: 31100, MarginPercent: 65, CustomerRating: 4.2, GrowthRate: 11 },
  { Date: "2026-03-02", Country: "Canada", Segment: "SMB", Category: "Hardware Solutions", Sales: 17200, MarginPercent: 32, CustomerRating: 4.4, GrowthRate: 4 },
  { Date: "2026-03-15", Country: "UK", Segment: "Enterprise", Category: "Cloud Infrastructure", Sales: 52000, MarginPercent: 72, CustomerRating: 4.8, GrowthRate: 21 },
  { Date: "2026-03-29", Country: "USA", Segment: "SMB", Category: "Consulting Services", Sales: 19000, MarginPercent: 48, CustomerRating: 4.3, GrowthRate: 14 },
  { Date: "2026-04-10", Country: "UK", Segment: "Mid-Market", Category: "SaaS Software", Sales: 33500, MarginPercent: 78, CustomerRating: 4.6, GrowthRate: 9 },
  { Date: "2026-04-22", Country: "Germany", Segment: "Enterprise", Category: "Hardware Solutions", Sales: 64100, MarginPercent: 35, CustomerRating: 4.9, GrowthRate: 24 },
  { Date: "2026-05-05", Country: "Canada", Segment: "SMB", Category: "SaaS Software", Sales: 22800, MarginPercent: 85, CustomerRating: 4.0, GrowthRate: 13 },
  { Date: "2026-05-18", Country: "UK", Segment: "Enterprise", Category: "Consulting Services", Sales: 39500, MarginPercent: 50, CustomerRating: 4.5, GrowthRate: 10 },
  { Date: "2026-06-01", Country: "USA", Segment: "Mid-Market", Category: "Hardware Solutions", Sales: 35000, MarginPercent: 30, CustomerRating: 4.2, GrowthRate: 6 },
  { Date: "2026-06-14", Country: "Germany", Segment: "SMB", Category: "Cloud Infrastructure", Sales: 26800, MarginPercent: 70, CustomerRating: 4.5, GrowthRate: 16 },
  { Date: "2026-06-28", Country: "Canada", Segment: "Enterprise", Category: "SaaS Software", Sales: 58900, MarginPercent: 81, CustomerRating: 4.7, GrowthRate: 22 },
];

export default function App() {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [activeTab, setActiveTab] = useState<'overview' | 'stats' | 'advanced' | 'charts' | 'ai' | 'report'>('overview');
  const [bgOpacity, setBgOpacity] = useState<number>(0.12);
  
  // Dataset States
  const [summary, setSummary] = useState<DatasetSummary | null>(null);
  const [filters, setFilters] = useState<FilterCondition[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [dragOver, setDragOver] = useState<boolean>(false);

  // AI Insights States
  const [aiQuestions, setAiQuestions] = useState<BusinessQuestion[]>([]);
  const [aiConclusions, setAiConclusions] = useState<string[]>([]);
  const [aiRecommendations, setAiRecommendations] = useState<string[]>([]);
  const [aiInsightsCache, setAiInsightsCache] = useState<Record<string, string>>({});
  const [aiLoading, setAiLoading] = useState<boolean>(false);

  // Initialize Theme class
  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  // Apply filters in memory to data rows
  const filteredRows = useMemo(() => {
    if (!summary) return [];
    if (filters.length === 0) return summary.allRows;

    return summary.allRows.filter(row => {
      return filters.every(filter => {
        const val = row[filter.columnName];
        if (val === null || val === undefined) {
          return filter.operator === 'not_empty' ? false : false;
        }

        const strVal = String(val).toLowerCase();
        const compVal = filter.value.toLowerCase();

        switch (filter.operator) {
          case 'contains':
            return strVal.includes(compVal);
          case 'equals':
            return strVal === compVal;
          case 'greater_than':
            return Number(val) > Number(filter.value);
          case 'less_than':
            return Number(val) < Number(filter.value);
          case 'not_empty':
            return String(val).trim() !== '';
          default:
            return true;
        }
      });
    });
  }, [summary, filters]);

  // Compute active statistics dynamically based on filtered rows
  const activeSummary = useMemo(() => {
    if (!summary) return null;
    return analyzeDataset(summary.fileName, summary.fileSize, filteredRows);
  }, [summary, filteredRows]);

  // Call API to fetch business questions, conclusions, and recommendations
  const fetchGlobalAiInsights = async (fileName: string, cols: ColumnMetadata[], totalRows: number) => {
    setAiLoading(true);
    try {
      // 1. Fetch questions
      const qRes = await fetch('/api/eda/questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileName, columns: cols, rowCount: totalRows })
      });
      const qData = await qRes.json();
      if (qData.questions) setAiQuestions(qData.questions);

      // 2. Fetch overall reports (conclusions & recommendations)
      const rRes = await fetch('/api/eda/report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileName, summaryStats: { rowCount: totalRows, columnCount: cols.length, columns: cols.slice(0, 8) } })
      });
      const rData = await rRes.json();
      if (rData.conclusions) setAiConclusions(rData.conclusions);
      if (rData.recommendations) setAiRecommendations(rData.recommendations);
    } catch (err) {
      console.error('Error generating global AI recommendations:', err);
    } finally {
      setAiLoading(false);
    }
  };

  // Handler for parsing raw rows
  const handleDatasetLoaded = (fileName: string, fileSize: number, rows: Record<string, any>[]) => {
    setLoading(true);
    try {
      const stats = analyzeDataset(fileName, fileSize, rows);
      setSummary(stats);
      setFilters([]);
      setAiInsightsCache({});
      
      // Fire-and-forget background global strategic insight fetching
      fetchGlobalAiInsights(fileName, stats.columns, stats.rowCount);
      setActiveTab('overview');
    } catch (err) {
      console.error('Error analyzing uploaded file:', err);
    } finally {
      setLoading(false);
    }
  };

  // Load sample dataset
  const handleLoadSample = () => {
    handleDatasetLoaded('Global_Enterprise_Tech_Sales_Sample.csv', 145000, SAMPLE_DATASET);
  };

  // CSV parsing trigger
  const handleCsvFile = (file: File) => {
    setLoading(true);
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      dynamicTyping: true,
      complete: (results) => {
        handleDatasetLoaded(file.name, file.size, results.data as Record<string, any>[]);
      },
      error: (err) => {
        console.error('CSV parse error:', err);
        setLoading(false);
      }
    });
  };

  // Excel parsing trigger
  const handleExcelFile = (file: File) => {
    setLoading(true);
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        if (data) {
          const workbook = XLSX.read(data, { type: 'binary' });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          const rows = XLSX.utils.sheet_to_json(worksheet) as Record<string, any>[];
          handleDatasetLoaded(file.name, file.size, rows);
        }
      } catch (err) {
        console.error('Excel parse error:', err);
      } finally {
        setLoading(false);
      }
    };
    reader.readAsBinaryString(file);
  };

  // File Upload Handlers
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.name.endsWith('.csv')) {
        handleCsvFile(file);
      } else if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
        handleExcelFile(file);
      }
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = () => {
    setDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      if (file.name.endsWith('.csv')) {
        handleCsvFile(file);
      } else if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
        handleExcelFile(file);
      }
    }
  };

  // Filter modifiers
  const handleAddFilter = (cond: FilterCondition) => {
    setFilters(prev => [...prev, cond]);
  };

  const handleRemoveFilter = (index: number) => {
    setFilters(prev => prev.filter((_, idx) => idx !== index));
  };

  const handleClearFilters = () => {
    setFilters([]);
  };

  const handleResetDataset = () => {
    setSummary(null);
    setFilters([]);
    setAiQuestions([]);
    setAiConclusions([]);
    setAiRecommendations([]);
    setAiInsightsCache({});
  };

  return (
    <div className="relative min-h-screen bg-slate-50 dark:bg-slate-950 transition-colors duration-500 text-slate-800 dark:text-slate-100 font-sans selection:bg-pink-500 selection:text-white pb-12">
      
      {/* Dynamic Background Image Layer */}
      <div 
        id="app-bg-image"
        className="fixed inset-0 pointer-events-none z-0 bg-cover bg-center bg-no-repeat transition-opacity duration-500"
        style={{ 
          backgroundImage: "url('/exploratory_data_analysis.png')",
          opacity: bgOpacity,
        }}
      />
      
      {/* Dynamic Animated Ambient Background Blobs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        {/* Blob A - Pink */}
        <motion.div
          animate={{
            x: [0, 60, -40, 0],
            y: [0, -60, 40, 0],
            scale: [1, 1.15, 0.9, 1],
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute top-[10%] left-[5%] w-[350px] h-[350px] bg-gradient-to-tr from-pink-500/10 to-pink-400/5 rounded-full filter blur-3xl"
        />

        {/* Blob B - Emerald */}
        <motion.div
          animate={{
            x: [0, -80, 50, 0],
            y: [0, 60, -50, 0],
            scale: [1, 0.85, 1.1, 1],
          }}
          transition={{
            duration: 30,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute bottom-[20%] right-[5%] w-[400px] h-[400px] bg-gradient-to-tr from-emerald-500/10 to-emerald-400/5 rounded-full filter blur-3xl"
        />

        {/* Blob C - Violet */}
        <motion.div
          animate={{
            x: [0, 40, -50, 0],
            y: [0, 50, -60, 0],
            scale: [0.9, 1.05, 0.95, 0.9],
          }}
          transition={{
            duration: 22,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute top-[40%] right-[25%] w-[300px] h-[300px] bg-gradient-to-tr from-violet-500/5 to-pink-500/5 rounded-full filter blur-3xl"
        />
      </div>

      {/* Decorative ambient glowing grids in dark mode */}
      <div className="absolute top-0 inset-x-0 h-96 bg-gradient-to-b from-pink-500/5 via-transparent to-transparent pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-emerald-500/5 rounded-full filter blur-3xl pointer-events-none" />

      {/* Main Header */}
      <header id="main-header" className="sticky top-0 z-40 backdrop-blur-md bg-white/70 dark:bg-slate-950/70 border-b border-slate-200/50 dark:border-slate-900/50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 bg-gradient-to-tr from-pink-500 to-emerald-500 rounded-xl flex items-center justify-center shadow-lg shadow-pink-500/20">
              <Database className="w-5 h-5 text-white animate-pulse" />
            </div>
            <div>
              <h1 className="text-sm font-bold tracking-tight text-slate-900 dark:text-white uppercase">Exploratory Data Analysis</h1>
              <p className="text-[10px] text-slate-500 font-semibold tracking-wider uppercase">Senior Business Intelligence Hub</p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            {/* Theme Toggle */}
            <button
              onClick={() => setTheme(prev => prev === 'dark' ? 'light' : 'dark')}
              className="p-2 bg-slate-100 dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800 rounded-xl hover:border-pink-500/40 transition cursor-pointer"
              title="Toggle Dark/Light Mode"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-pink-600" />}
            </button>

            {/* Background Image Toggle & Opacity Cycler */}
            <button
              onClick={() => {
                setBgOpacity(prev => {
                  if (prev === 0) return 0.06;
                  if (prev === 0.06) return 0.12;
                  if (prev === 0.12) return 0.22;
                  return 0; // Cycles: 0% -> 6% -> 12% -> 22% -> 0%
                });
              }}
              className="p-2 bg-slate-100 dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800 rounded-xl hover:border-pink-500/40 transition cursor-pointer flex items-center space-x-1.5"
              title="Cycle Background Opacity"
            >
              <Image className={`w-4 h-4 ${bgOpacity > 0 ? 'text-pink-500' : 'text-slate-400'}`} />
              <span className="text-[10px] font-mono font-bold text-slate-600 dark:text-slate-300">
                {bgOpacity === 0 ? 'Off' : bgOpacity === 0.06 ? '6%' : bgOpacity === 0.12 ? '12%' : '22%'}
              </span>
            </button>

            {/* Quick stats indicator */}
            {summary && (
              <div className="hidden sm:flex items-center space-x-2 px-3 py-1 bg-pink-50 dark:bg-pink-950/20 text-pink-600 dark:text-pink-400 border border-pink-100 dark:border-pink-900/30 rounded-xl text-xs font-mono">
                <Sliders className="w-3.5 h-3.5" />
                <span>Rows: {filteredRows.length.toLocaleString()}</span>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 mt-8">
        {!summary ? (
          /* ================== UPLOAD SCREEN ================== */
          <div className="max-w-2xl mx-auto py-12 space-y-6">
            <GlassCard id="welcome-card" glowColor="pink" className="text-center p-8 border-pink-500/10">
              <span className="px-2.5 py-0.5 bg-pink-100 dark:bg-pink-950/40 text-pink-600 dark:text-pink-400 font-bold rounded-full text-[10px] tracking-wider uppercase">Senior Data Analyst AI Workspace</span>
              <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white mt-3 tracking-tight">
                Exploratory Data Analysis Suite
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 max-w-md mx-auto leading-relaxed">
                Upload custom enterprise tables. Instantly detect schemas, missing values, duplicates, outliers, and calculate Pearson correlation matrices, paired with server-side strategic recommendations.
              </p>

              {/* Theme Illustration Preview */}
              <div className="mt-6 mb-2 relative overflow-hidden rounded-2xl border border-slate-200/50 dark:border-slate-800/50 shadow-lg max-w-md mx-auto aspect-[4/3] bg-slate-100 dark:bg-slate-900/60 transition group hover:scale-[1.01] duration-300">
                <img 
                  src="/exploratory_data_analysis.png" 
                  alt="Exploratory Data Analysis Penguins Illustration" 
                  className="w-full h-full object-cover select-none"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/25 via-transparent to-transparent pointer-events-none" />
              </div>
            </GlassCard>

            {/* Drag and drop upload viewport */}
            <div
              id="drop-zone"
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`
                border-2 border-dashed rounded-3xl p-10 text-center transition-all duration-300 relative overflow-hidden backdrop-blur-md
                ${dragOver
                  ? 'border-pink-500 bg-pink-500/10 scale-[1.02]'
                  : 'border-slate-300 dark:border-slate-800 hover:border-pink-500/40 bg-white/40 dark:bg-slate-900/30'
                }
              `}
            >
              <div className="relative z-10 flex flex-col items-center">
                <div className="p-4 bg-pink-50 dark:bg-pink-950/30 rounded-full text-pink-500 mb-4 animate-bounce">
                  <UploadCloud className="w-10 h-10" />
                </div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  Drag and Drop CSV or Excel Document
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
                  Supports .csv and .xlsx spreadsheets. Slicers recompute all downstream calculations instantly.
                </p>

                <div className="mt-6">
                  <label className="bg-pink-500 hover:bg-pink-600 text-white text-xs font-bold px-5 py-2.5 rounded-xl shadow-lg shadow-pink-500/20 transition cursor-pointer inline-block active:scale-95">
                    Browse File System
                    <input
                      type="file"
                      accept=".csv, .xlsx, .xls"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>
            </div>

            {/* Direct Quick Sample Data Loader */}
            <div className="text-center">
              <span className="text-xs text-slate-400 font-semibold block uppercase tracking-wider mb-2">No dataset on hand?</span>
              <button
                type="button"
                onClick={handleLoadSample}
                className="inline-flex items-center space-x-2 px-5 py-3 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white text-xs font-bold rounded-xl shadow-lg shadow-emerald-500/25 transition cursor-pointer active:scale-95"
              >
                <Sparkles className="w-4 h-4 animate-spin" />
                <span>Load High-Fidelity Enterprise Sample</span>
              </button>
            </div>
          </div>
        ) : (
          /* ================== MAIN ANALYTICS DASHBOARD ================== */
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
            
            {/* Sidebar Controls Layout */}
            <div className="lg:col-span-1 space-y-4 sticky top-20">
              <GlassCard id="sidebar-meta" glowColor="pink" hoverEffect={false}>
                <div className="flex justify-between items-start border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
                  <div className="truncate max-w-[150px]">
                    <span className="text-[10px] uppercase font-bold tracking-widest text-pink-500">Active File</span>
                    <h3 className="font-bold text-xs truncate mt-0.5 text-slate-900 dark:text-white" title={summary.fileName}>
                      {summary.fileName}
                    </h3>
                  </div>
                  <button
                    onClick={handleResetDataset}
                    className="text-[10px] font-bold text-pink-500 hover:text-pink-600 px-2 py-1 bg-pink-500/10 rounded-lg cursor-pointer"
                  >
                    Upload New
                  </button>
                </div>

                {/* Left Drawer Navigation Links */}
                <div className="space-y-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300">
                  <button
                    onClick={() => setActiveTab('overview')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition cursor-pointer ${
                      activeTab === 'overview'
                        ? 'bg-gradient-to-r from-pink-500 to-pink-600 text-white shadow-sm'
                        : 'hover:bg-slate-100 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    <span className="flex items-center space-x-2">
                      <LayoutDashboard className="w-4 h-4" />
                      <span>Dataset Overview</span>
                    </span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => setActiveTab('stats')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition cursor-pointer ${
                      activeTab === 'stats'
                        ? 'bg-gradient-to-r from-pink-500 to-pink-600 text-white shadow-sm'
                        : 'hover:bg-slate-100 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    <span className="flex items-center space-x-2">
                      <Table className="w-4 h-4" />
                      <span>Descriptive Summaries</span>
                    </span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => setActiveTab('advanced')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition cursor-pointer ${
                      activeTab === 'advanced'
                        ? 'bg-gradient-to-r from-pink-500 to-pink-600 text-white shadow-sm'
                        : 'hover:bg-slate-100 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    <span className="flex items-center space-x-2">
                      <Sliders className="w-4 h-4" />
                      <span>Correlation & Outliers</span>
                    </span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => setActiveTab('charts')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition cursor-pointer ${
                      activeTab === 'charts'
                        ? 'bg-gradient-to-r from-pink-500 to-pink-600 text-white shadow-sm'
                        : 'hover:bg-slate-100 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    <span className="flex items-center space-x-2">
                      <BarChart2 className="w-4 h-4" />
                      <span>Interactive Visualizations</span>
                    </span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => setActiveTab('ai')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition cursor-pointer ${
                      activeTab === 'ai'
                        ? 'bg-gradient-to-r from-pink-500 to-pink-600 text-white shadow-sm shadow-pink-500/10'
                        : 'hover:bg-slate-100 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    <span className="flex items-center space-x-2">
                      <Sparkles className="w-4 h-4 text-emerald-500 animate-pulse" />
                      <span>AI Business Consulting</span>
                    </span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => setActiveTab('report')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition cursor-pointer ${
                      activeTab === 'report'
                        ? 'bg-gradient-to-r from-pink-500 to-pink-600 text-white shadow-sm'
                        : 'hover:bg-slate-100 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    <span className="flex items-center space-x-2">
                      <FileText className="w-4 h-4" />
                      <span>Report Download Center</span>
                    </span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </GlassCard>

              {/* Slicer state display */}
              {filters.length > 0 && (
                <GlassCard id="active-filters-widget" glowColor="none" className="p-4 border-emerald-500/10">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-500 block mb-2">Active Row Slicers</span>
                  <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-400">
                    <p className="text-[10px]">Your current row slice represents {filteredRows.length.toLocaleString()} rows of data.</p>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {filters.map((filter, index) => (
                        <div key={index} className="px-2 py-0.5 bg-slate-150 dark:bg-slate-800 rounded font-mono text-[9px] flex items-center space-x-1">
                          <span>{filter.columnName}</span>
                          <button onClick={() => handleRemoveFilter(index)} className="hover:text-pink-500">
                            <X className="w-2.5 h-2.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </GlassCard>
              )}
            </div>

            {/* Main Tabs Layout Area */}
            <div className="lg:col-span-3 space-y-6">
              <AnimatePresence mode="wait">
                {activeTab === 'overview' && activeSummary && (
                  <motion.div
                    key="overview"
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -15 }}
                    transition={{ duration: 0.25, ease: "easeOut" }}
                  >
                    <DataOverview
                      summary={activeSummary}
                      filteredRows={filteredRows}
                      filters={filters}
                      onAddFilter={handleAddFilter}
                      onRemoveFilter={handleRemoveFilter}
                      onClearFilters={handleClearFilters}
                    />
                  </motion.div>
                )}

                {activeTab === 'stats' && activeSummary && (
                  <motion.div
                    key="stats"
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -15 }}
                    transition={{ duration: 0.25, ease: "easeOut" }}
                  >
                    <StatsSummary
                      summary={activeSummary}
                      filteredRows={filteredRows}
                    />
                  </motion.div>
                )}

                {activeTab === 'advanced' && activeSummary && (
                  <motion.div
                    key="advanced"
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -15 }}
                    transition={{ duration: 0.25, ease: "easeOut" }}
                  >
                    <AdvancedAnalytics
                      summary={activeSummary}
                    />
                  </motion.div>
                )}

                {activeTab === 'charts' && activeSummary && (
                  <motion.div
                    key="charts"
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -15 }}
                    transition={{ duration: 0.25, ease: "easeOut" }}
                  >
                    <Visualizations
                      summary={activeSummary}
                      filteredRows={filteredRows}
                      aiInsightsCache={aiInsightsCache}
                      onSaveInsight={(key, value) => {
                        setAiInsightsCache(prev => ({ ...prev, [key]: value }));
                      }}
                    />
                  </motion.div>
                )}

                {activeTab === 'ai' && activeSummary && (
                  <motion.div
                    key="ai"
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -15 }}
                    transition={{ duration: 0.25, ease: "easeOut" }}
                  >
                    <AiRecommendations
                      summary={activeSummary}
                      questions={aiQuestions}
                      conclusions={aiConclusions}
                      recommendations={aiRecommendations}
                      loading={aiLoading}
                      onRefresh={() => {
                        fetchGlobalAiInsights(activeSummary.fileName, activeSummary.columns, activeSummary.rowCount);
                      }}
                    />
                  </motion.div>
                )}

                {activeTab === 'report' && activeSummary && (
                  <motion.div
                    key="report"
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -15 }}
                    transition={{ duration: 0.25, ease: "easeOut" }}
                  >
                    <ReportGenerator
                      summary={activeSummary}
                      questions={aiQuestions}
                      conclusions={aiConclusions}
                      recommendations={aiRecommendations}
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
