import React, { useState, useEffect } from 'react';
import { ColumnMetadata, DatasetSummary } from '../types';
import GlassCard from './GlassCard';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  ScatterChart, Scatter, LineChart, Line, PieChart, Pie, Cell
} from 'recharts';
import { getDistributionData, getRelationshipData, getCategoricalAnalysis, getTimeSeriesAnalysis } from '../utils/analysis';
import { Sparkles, BarChart3, ScatterChart as ScatterIcon, Activity, PieChart as PieIcon, RefreshCw, MessageSquareCode } from 'lucide-react';

interface VisualizationsProps {
  summary: DatasetSummary;
  filteredRows: Record<string, any>[];
  aiInsightsCache: Record<string, string>;
  onSaveInsight: (key: string, insight: string) => void;
}

export const Visualizations: React.FC<VisualizationsProps> = ({
  summary,
  filteredRows,
  aiInsightsCache,
  onSaveInsight
}) => {
  const numericCols = summary.columns.filter(c => c.type === 'numeric');
  const categoricalCols = summary.columns.filter(c => c.type === 'categorical' || c.type === 'boolean');
  const dateCols = summary.columns.filter(c => c.type === 'datetime');

  // Chart view selections
  const [activeSubTab, setActiveSubTab] = useState<'distribution' | 'relationship' | 'category' | 'time_series'>('distribution');

  // 1. Distribution state
  const [distCol, setDistCol] = useState<string>(summary.columns[0]?.name || '');
  const [distBins, setDistBins] = useState<number>(10);

  // 2. Relationship (Scatter) state
  const [scatX, setScatX] = useState<string>(numericCols[0]?.name || '');
  const [scatY, setScatY] = useState<string>(numericCols[1]?.name || numericCols[0]?.name || '');

  // 3. Category state
  const [catGroup, setCatGroup] = useState<string>(categoricalCols[0]?.name || summary.columns[0]?.name || '');
  const [catMetric, setCatMetric] = useState<string>(numericCols[0]?.name || '');
  const [catAggMode, setCatAggMode] = useState<'sum' | 'average'>('average');
  const [catChartType, setCatChartType] = useState<'bar' | 'pie'>('bar');

  // 4. Time Series state
  const [timeDateCol, setTimeDateCol] = useState<string>(dateCols[0]?.name || '');
  const [timeMetric, setTimeMetric] = useState<string>(numericCols[0]?.name || '');

  // AI loading state
  const [loadingInsight, setLoadingInsight] = useState<boolean>(false);

  // Derive active variables for AI prompts
  const getActiveConfigInfo = () => {
    switch (activeSubTab) {
      case 'distribution':
        return {
          key: `dist_${distCol}_bins_${distBins}`,
          type: 'distribution',
          xName: distCol,
          yName: 'Frequency',
          summary: getDistributionData(filteredRows, summary.columns.find(c => c.name === distCol) || summary.columns[0], distBins)
        };
      case 'relationship':
        return {
          key: `rel_${scatX}_vs_${scatY}`,
          type: 'scatter_relationship',
          xName: scatX,
          yName: scatY,
          summary: getRelationshipData(filteredRows, scatX, scatY, 8).map(p => ({ x: p.x, y: p.y })) // concise summary for Gemini
        };
      case 'category':
        return {
          key: `cat_${catGroup}_vs_${catMetric}_${catAggMode}`,
          type: 'categorical_aggregate',
          xName: catGroup,
          yName: `${catMetric} (${catAggMode})`,
          summary: getCategoricalAnalysis(filteredRows, catGroup, catMetric).slice(0, 8)
        };
      case 'time_series':
        return {
          key: `time_${timeDateCol}_vs_${timeMetric}`,
          type: 'time_series_trend',
          xName: timeDateCol,
          yName: timeMetric,
          summary: getTimeSeriesAnalysis(filteredRows, timeDateCol, timeMetric).slice(0, 10)
        };
    }
  };

  const activeConfig = getActiveConfigInfo();
  const currentInsight = aiInsightsCache[activeConfig.key] || '';

  // API call to fetch AI Insight
  const fetchAiInsight = async (force = false) => {
    if (!force && aiInsightsCache[activeConfig.key]) return;

    setLoadingInsight(true);
    try {
      const response = await fetch('/api/eda/insight', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chartType: activeConfig.type,
          columnNameX: activeConfig.xName,
          columnNameY: activeConfig.yName,
          summaryData: activeConfig.summary
        })
      });
      const data = await response.json();
      if (data.insight) {
        onSaveInsight(activeConfig.key, data.insight);
      }
    } catch (err) {
      console.error('Error fetching AI chart insight:', err);
    } finally {
      setLoadingInsight(false);
    }
  };

  // Fetch insight on tab/selection change
  useEffect(() => {
    if (activeConfig.xName) {
      fetchAiInsight(false);
    }
  }, [activeSubTab, distCol, distBins, scatX, scatY, catGroup, catMetric, catAggMode, timeDateCol, timeMetric, filteredRows]);

  // Color theme palettes
  const COLORS_PINK_GREEN = [
    '#ec4899', '#10b981', '#3b82f6', '#f43f5e', '#059669',
    '#db2777', '#34d399', '#f472b6', '#a855f7', '#14b8a6'
  ];

  return (
    <div id="visualizations-container" className="space-y-6">
      {/* Sub tabs for chart categories */}
      <div id="chart-tabs-bar" className="flex flex-wrap border-b border-slate-200 dark:border-slate-800 gap-1 pb-1">
        <button
          onClick={() => setActiveSubTab('distribution')}
          className={`px-4 py-2 text-xs font-semibold rounded-t-xl flex items-center space-x-1.5 transition cursor-pointer ${
            activeSubTab === 'distribution'
              ? 'bg-pink-500/10 dark:bg-pink-500/20 text-pink-600 dark:text-pink-400 border-b-2 border-pink-500'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Distribution Analysis</span>
        </button>
        <button
          onClick={() => setActiveSubTab('relationship')}
          className={`px-4 py-2 text-xs font-semibold rounded-t-xl flex items-center space-x-1.5 transition cursor-pointer ${
            activeSubTab === 'relationship'
              ? 'bg-pink-500/10 dark:bg-pink-500/20 text-pink-600 dark:text-pink-400 border-b-2 border-pink-500'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800'
          }`}
        >
          <ScatterIcon className="w-4 h-4" />
          <span>Feature Relationships</span>
        </button>
        <button
          onClick={() => setActiveSubTab('category')}
          className={`px-4 py-2 text-xs font-semibold rounded-t-xl flex items-center space-x-1.5 transition cursor-pointer ${
            activeSubTab === 'category'
              ? 'bg-pink-500/10 dark:bg-pink-500/20 text-pink-600 dark:text-pink-400 border-b-2 border-pink-500'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800'
          }`}
        >
          <PieIcon className="w-4 h-4" />
          <span>Category Analysis</span>
        </button>
        <button
          onClick={() => setActiveSubTab('time_series')}
          className={`px-4 py-2 text-xs font-semibold rounded-t-xl flex items-center space-x-1.5 transition cursor-pointer ${
            activeSubTab === 'time_series'
              ? 'bg-pink-500/10 dark:bg-pink-500/20 text-pink-600 dark:text-pink-400 border-b-2 border-pink-500'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Time Series Trends</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Controls Column */}
        <div className="lg:col-span-1 space-y-4">
          <GlassCard id="chart-controls-panel">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4">Chart Parameters</h4>

            {/* Render controls based on tab */}
            {activeSubTab === 'distribution' && (
              <div className="space-y-4 text-xs">
                <div className="space-y-1">
                  <label className="text-slate-500 font-semibold">Distribution Variable</label>
                  <select
                    value={distCol}
                    onChange={(e) => setDistCol(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-800 dark:text-slate-200 outline-none"
                  >
                    {summary.columns.map(c => (
                      <option key={c.name} value={c.name}>{c.name} ({c.type})</option>
                    ))}
                  </select>
                </div>
                {summary.columns.find(c => c.name === distCol)?.type === 'numeric' && (
                  <div className="space-y-1">
                    <label className="text-slate-500 font-semibold">Histogram Bins: {distBins}</label>
                    <input
                      type="range"
                      min="5"
                      max="30"
                      step="5"
                      value={distBins}
                      onChange={(e) => setDistBins(Number(e.target.value))}
                      className="w-full accent-pink-500 cursor-pointer"
                    />
                  </div>
                )}
              </div>
            )}

            {activeSubTab === 'relationship' && (
              <div className="space-y-4 text-xs">
                {numericCols.length < 1 ? (
                  <p className="text-red-500">Scatter plots require numeric columns.</p>
                ) : (
                  <>
                    <div className="space-y-1">
                      <label className="text-slate-500 font-semibold">X-Axis Variable</label>
                      <select
                        value={scatX}
                        onChange={(e) => setScatX(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-800 dark:text-slate-200 outline-none"
                      >
                        {numericCols.map(c => (
                          <option key={c.name} value={c.name}>{c.name}</option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-slate-500 font-semibold">Y-Axis Variable</label>
                      <select
                        value={scatY}
                        onChange={(e) => setScatY(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-800 dark:text-slate-200 outline-none"
                      >
                        {numericCols.map(c => (
                          <option key={c.name} value={c.name}>{c.name}</option>
                        ))}
                      </select>
                    </div>
                  </>
                )}
              </div>
            )}

            {activeSubTab === 'category' && (
              <div className="space-y-4 text-xs">
                {numericCols.length === 0 ? (
                  <p className="text-red-500">Category grouping analysis requires at least 1 numeric column to aggregate.</p>
                ) : (
                  <>
                    <div className="space-y-1">
                      <label className="text-slate-500 font-semibold">Category Column</label>
                      <select
                        value={catGroup}
                        onChange={(e) => setCatGroup(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-800 dark:text-slate-200 outline-none"
                      >
                        {categoricalCols.map(c => (
                          <option key={c.name} value={c.name}>{c.name}</option>
                        ))}
                        {/* Fallback to show any columns if none strictly categorical */}
                        {categoricalCols.length === 0 && summary.columns.map(c => (
                          <option key={c.name} value={c.name}>{c.name}</option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-slate-500 font-semibold">Numerical Measure</label>
                      <select
                        value={catMetric}
                        onChange={(e) => setCatMetric(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-800 dark:text-slate-200 outline-none"
                      >
                        {numericCols.map(c => (
                          <option key={c.name} value={c.name}>{c.name}</option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-slate-500 font-semibold">Aggregation Mode</label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setCatAggMode('sum')}
                          className={`py-1.5 rounded-lg border text-[10px] font-bold ${
                            catAggMode === 'sum'
                              ? 'bg-pink-500/10 text-pink-600 border-pink-500'
                              : 'bg-white dark:bg-slate-850 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          SUM
                        </button>
                        <button
                          type="button"
                          onClick={() => setCatAggMode('average')}
                          className={`py-1.5 rounded-lg border text-[10px] font-bold ${
                            catAggMode === 'average'
                              ? 'bg-pink-500/10 text-pink-600 border-pink-500'
                              : 'bg-white dark:bg-slate-850 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          AVERAGE
                        </button>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <label className="text-slate-500 font-semibold">Visual Format</label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setCatChartType('bar')}
                          className={`py-1.5 rounded-lg border text-[10px] font-bold ${
                            catChartType === 'bar'
                              ? 'bg-pink-500/10 text-pink-600 border-pink-500'
                              : 'bg-white dark:bg-slate-850 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          BARS
                        </button>
                        <button
                          type="button"
                          onClick={() => setCatChartType('pie')}
                          className={`py-1.5 rounded-lg border text-[10px] font-bold ${
                            catChartType === 'pie'
                              ? 'bg-pink-500/10 text-pink-600 border-pink-500'
                              : 'bg-white dark:bg-slate-850 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          PIE
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}

            {activeSubTab === 'time_series' && (
              <div className="space-y-4 text-xs">
                {dateCols.length === 0 ? (
                  <p className="text-amber-500">No datetime-like columns detected. Please verify your file contains structured calendar dates.</p>
                ) : numericCols.length === 0 ? (
                  <p className="text-red-500">Trends require at least 1 numeric metric column.</p>
                ) : (
                  <>
                    <div className="space-y-1">
                      <label className="text-slate-500 font-semibold">Datetime Variable</label>
                      <select
                        value={timeDateCol}
                        onChange={(e) => setTimeDateCol(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-800 dark:text-slate-200 outline-none"
                      >
                        {dateCols.map(c => (
                          <option key={c.name} value={c.name}>{c.name}</option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-slate-500 font-semibold">Y-Axis Metric</label>
                      <select
                        value={timeMetric}
                        onChange={(e) => setTimeMetric(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-800 dark:text-slate-200 outline-none"
                      >
                        {numericCols.map(c => (
                          <option key={c.name} value={c.name}>{c.name}</option>
                        ))}
                      </select>
                    </div>
                  </>
                )}
              </div>
            )}
          </GlassCard>
        </div>

        {/* Plotting Area (lg:col-span-3) */}
        <div className="lg:col-span-3 space-y-6">
          <GlassCard id="active-chart-viewport" glowColor="none" className="min-h-[380px] flex flex-col justify-between">
            {/* Chart Title */}
            <div className="border-b border-slate-100 dark:border-slate-800 pb-3 mb-4 flex justify-between items-center text-slate-900 dark:text-white">
              <h3 className="font-bold text-sm tracking-wide flex items-center space-x-1.5 uppercase">
                <span className="w-2.5 h-2.5 bg-pink-500 rounded-full" />
                {activeSubTab === 'distribution' && <span>Value Distribution ({distCol})</span>}
                {activeSubTab === 'relationship' && <span>Correlation Relationship: {scatX} vs {scatY}</span>}
                {activeSubTab === 'category' && <span>Category Aggregate: {catMetric} by {catGroup}</span>}
                {activeSubTab === 'time_series' && <span>Temporal Trend: {timeMetric} over {timeDateCol}</span>}
              </h3>
              <span className="text-[10px] px-2.5 py-0.5 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-400 font-bold tracking-wider rounded-md border border-emerald-100 dark:border-emerald-900/30">
                ACTIVE SLICER APPLIED
              </span>
            </div>

            {/* Render Recharts Plot */}
            <div className="h-[280px] w-full">
              {activeSubTab === 'distribution' && (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={getDistributionData(filteredRows, summary.columns.find(c => c.name === distCol) || summary.columns[0], distBins)}
                    margin={{ top: 5, right: 10, left: -20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#88888820" />
                    <XAxis dataKey="name" stroke="#88888880" fontSize={10} tickLine={false} />
                    <YAxis stroke="#88888880" fontSize={10} tickLine={false} />
                    <Tooltip
                      contentStyle={{
                        background: 'rgba(15, 23, 42, 0.9)',
                        border: '1px solid rgba(236,72,153,0.3)',
                        borderRadius: '12px',
                        color: '#fff',
                        fontFamily: 'monospace',
                        fontSize: '11px'
                      }}
                    />
                    <Bar dataKey="value" fill="#ec4899" radius={[6, 6, 0, 0]}>
                      {getDistributionData(filteredRows, summary.columns.find(c => c.name === distCol) || summary.columns[0], distBins).map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#ec4899' : '#10b981'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              )}

              {activeSubTab === 'relationship' && (
                numericCols.length >= 1 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <ScatterChart margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#88888820" />
                      <XAxis type="number" dataKey="x" name={scatX} stroke="#88888880" fontSize={10} />
                      <YAxis type="number" dataKey="y" name={scatY} stroke="#88888880" fontSize={10} />
                      <Tooltip
                        cursor={{ strokeDasharray: '3 3' }}
                        contentStyle={{
                          background: 'rgba(15, 23, 42, 0.9)',
                          border: '1px solid rgba(236,72,153,0.3)',
                          borderRadius: '12px',
                          color: '#fff',
                          fontSize: '11px'
                        }}
                      />
                      <Scatter name={`${scatX} vs ${scatY}`} data={getRelationshipData(filteredRows, scatX, scatY)} fill="#ec4899" />
                    </ScatterChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center justify-center text-slate-400">
                    Bivariate scatter plotting requires multiple numeric values.
                  </div>
                )
              )}

              {activeSubTab === 'category' && (
                numericCols.length > 0 ? (
                  catChartType === 'bar' ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={getCategoricalAnalysis(filteredRows, catGroup, catMetric)}
                        margin={{ top: 5, right: 10, left: -20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#88888820" />
                        <XAxis dataKey="name" stroke="#88888880" fontSize={10} tickLine={false} />
                        <YAxis stroke="#88888880" fontSize={10} tickLine={false} />
                        <Tooltip
                          contentStyle={{
                            background: 'rgba(15, 23, 42, 0.9)',
                            border: '1px solid rgba(236,72,153,0.3)',
                            borderRadius: '12px',
                            color: '#fff',
                            fontSize: '11px'
                          }}
                        />
                        <Legend wrapperStyle={{ fontSize: '10px' }} />
                        <Bar dataKey={catAggMode} name={`${catMetric} (${catAggMode})`} fill="#10b981" radius={[6, 6, 0, 0]}>
                          {getCategoricalAnalysis(filteredRows, catGroup, catMetric).map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#10b981' : '#ec4899'} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart margin={{ top: 5, right: 10, left: 10, bottom: 5 }}>
                        <Pie
                          data={getCategoricalAnalysis(filteredRows, catGroup, catMetric)}
                          dataKey={catAggMode}
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          outerRadius={80}
                          fill="#ec4899"
                          label={{ fontSize: 10, fill: '#888888' }}
                        >
                          {getCategoricalAnalysis(filteredRows, catGroup, catMetric).map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS_PINK_GREEN[index % COLORS_PINK_GREEN.length]} />
                          ))}
                        </Pie>
                        <Tooltip
                          contentStyle={{
                            background: 'rgba(15, 23, 42, 0.9)',
                            border: '1px solid rgba(236,72,153,0.3)',
                            borderRadius: '12px',
                            color: '#fff',
                            fontSize: '11px'
                          }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  )
                ) : (
                  <div className="h-full flex items-center justify-center text-slate-400">
                    Aggregation analysis requires at least 1 numeric column.
                  </div>
                )
              )}

              {activeSubTab === 'time_series' && (
                dateCols.length > 0 && numericCols.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={getTimeSeriesAnalysis(filteredRows, timeDateCol, timeMetric)}
                      margin={{ top: 5, right: 15, left: -20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#88888820" />
                      <XAxis dataKey="dateStr" stroke="#88888880" fontSize={10} tickLine={false} />
                      <YAxis stroke="#88888880" fontSize={10} tickLine={false} />
                      <Tooltip
                        contentStyle={{
                          background: 'rgba(15, 23, 42, 0.9)',
                          border: '1px solid rgba(236,72,153,0.3)',
                          borderRadius: '12px',
                          color: '#fff',
                          fontSize: '11px'
                        }}
                      />
                      <Legend wrapperStyle={{ fontSize: '10px' }} />
                      <Line type="monotone" dataKey="value" name={timeMetric} stroke="#ec4899" strokeWidth={2} dot={{ r: 2 }} />
                      <Line type="monotone" dataKey="rollingAvg" name="5-Point Rolling Avg" stroke="#10b981" strokeWidth={1.5} strokeDasharray="4 4" dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center justify-center text-center text-slate-400 p-6">
                    A datetime column and numeric column are required for temporal trends mapping.
                  </div>
                )
              )}
            </div>
          </GlassCard>

          {/* AI Generated Insight Box */}
          <GlassCard id="ai-insight-box" className="border-emerald-500/10" glowColor="green">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-3">
              <div className="flex items-center space-x-2 text-emerald-500">
                <Sparkles className="w-5 h-5 text-emerald-500 shrink-0" />
                <h4 className="font-bold text-sm text-slate-900 dark:text-white uppercase tracking-wide">AI Narrative Insight</h4>
              </div>
              <button
                onClick={() => fetchAiInsight(true)}
                disabled={loadingInsight || !activeConfig.xName}
                className="text-xs font-semibold text-pink-500 hover:text-pink-600 disabled:opacity-40 flex items-center space-x-1 cursor-pointer transition active:scale-95 bg-pink-50 dark:bg-pink-950/20 px-2.5 py-1 rounded-lg"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loadingInsight ? 'animate-spin' : ''}`} />
                <span>{loadingInsight ? 'Synthesizing...' : 'Re-Analyze'}</span>
              </button>
            </div>

            {loadingInsight ? (
              <div className="space-y-2 py-2">
                <div className="h-4 bg-slate-100 dark:bg-slate-800 rounded animate-pulse w-full" />
                <div className="h-4 bg-slate-100 dark:bg-slate-800 rounded animate-pulse w-[80%]" />
              </div>
            ) : currentInsight ? (
              <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed italic font-medium">
                "{currentInsight}"
              </p>
            ) : (
              <p className="text-xs text-slate-400 italic">
                No automatic narrative found. Click 'Re-Analyze' above to prompt our server-side LLM evaluator.
              </p>
            )}
          </GlassCard>
        </div>
      </div>
    </div>
  );
};
export default Visualizations;
