import React, { useState } from 'react';
import { ColumnMetadata, DatasetSummary } from '../types';
import GlassCard from './GlassCard';
import { Sigma, Percent, Copy, ShieldAlert, CheckCircle2, ChevronRight, HelpCircle } from 'lucide-react';

interface StatsSummaryProps {
  summary: DatasetSummary;
  filteredRows: Record<string, any>[];
}

export const StatsSummary: React.FC<StatsSummaryProps> = ({ summary, filteredRows }) => {
  const [selectedCol, setSelectedCol] = useState<string>(summary.columns[0]?.name || '');

  const activeCol = summary.columns.find(c => c.name === selectedCol) || summary.columns[0];

  // Helper to find duplicate indices/rows
  const findDuplicateSample = () => {
    const seen = new Set<string>();
    const dupes: { index: number; row: Record<string, any> }[] = [];
    
    for (let i = 0; i < summary.allRows.length; i++) {
      const rowStr = JSON.stringify(summary.allRows[i]);
      if (seen.has(rowStr)) {
        if (dupes.length < 5) {
          dupes.push({ index: i, row: summary.allRows[i] });
        }
      } else {
        seen.add(rowStr);
      }
    }
    return dupes;
  };

  const duplicateSample = findDuplicateSample();

  return (
    <div id="stats-summary-container" className="space-y-6">
      {/* Column Selector list */}
      <GlassCard id="stat-column-picker">
        <h4 className="text-sm font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3">
          Select Variable for Descriptive Profile
        </h4>
        <div className="flex flex-wrap gap-2">
          {summary.columns.map(c => (
            <button
              key={c.name}
              onClick={() => setSelectedCol(c.name)}
              className={`
                px-3 py-1.5 rounded-xl text-xs font-mono font-medium transition cursor-pointer active:scale-95
                ${selectedCol === c.name
                  ? 'bg-gradient-to-r from-pink-500 to-pink-600 text-white shadow-sm shadow-pink-500/20'
                  : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-pink-500/50'
                }
              `}
            >
              {c.name}
            </button>
          ))}
        </div>
      </GlassCard>

      {/* Selected Column Detail Stats */}
      {activeCol && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main profile card */}
          <GlassCard id="variable-card" glowColor="pink" className="lg:col-span-2">
            <div className="flex justify-between items-start border-b border-slate-100 dark:border-slate-800 pb-4 mb-4">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-widest text-pink-500">Selected Variable Profile</span>
                <h3 className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-0.5">{activeCol.name}</h3>
              </div>
              <span className="text-xs font-semibold px-2.5 py-1 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-full border border-slate-200 dark:border-slate-700">
                {activeCol.type.toUpperCase()}
              </span>
            </div>

            {activeCol.type === 'numeric' ? (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                  <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Arithmetic Mean (μ)</p>
                  <p className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-1">
                    {activeCol.mean !== undefined ? activeCol.mean.toLocaleString() : 'N/A'}
                  </p>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                  <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Median Value (Q2)</p>
                  <p className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-1">
                    {activeCol.median !== undefined ? activeCol.median.toLocaleString() : 'N/A'}
                  </p>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                  <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Std Deviation (σ)</p>
                  <p className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-1">
                    {activeCol.stdDev !== undefined ? activeCol.stdDev.toLocaleString() : 'N/A'}
                  </p>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                  <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">IQR range</p>
                  <p className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-1">
                    {activeCol.iqr !== undefined ? activeCol.iqr.toLocaleString() : 'N/A'}
                  </p>
                </div>

                <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                  <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Minimum (Min)</p>
                  <p className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-1">
                    {activeCol.min !== undefined ? activeCol.min.toLocaleString() : 'N/A'}
                  </p>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                  <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">25th Percentile (Q1)</p>
                  <p className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-1">
                    {activeCol.q1 !== undefined ? activeCol.q1.toLocaleString() : 'N/A'}
                  </p>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                  <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">75th Percentile (Q3)</p>
                  <p className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-1">
                    {activeCol.q3 !== undefined ? activeCol.q3.toLocaleString() : 'N/A'}
                  </p>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                  <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Maximum (Max)</p>
                  <p className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-1">
                    {activeCol.max !== undefined ? activeCol.max.toLocaleString() : 'N/A'}
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                    <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Unique Categories</p>
                    <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1">{activeCol.uniqueCount}</p>
                  </div>
                  <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                    <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Mode (Top Category)</p>
                    <p className="text-lg font-bold text-pink-600 dark:text-pink-400 truncate mt-1">
                      {activeCol.uniqueValues[0] || 'N/A'}
                    </p>
                  </div>
                  <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                    <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Data Completeness</p>
                    <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
                      {(100 - activeCol.missingPercentage).toFixed(1)}%
                    </p>
                  </div>
                </div>

                <div className="bg-slate-50 dark:bg-slate-900/30 rounded-xl p-4">
                  <h5 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Category Cardinallity Preview</h5>
                  <div className="flex flex-wrap gap-2">
                    {activeCol.uniqueValues.map((val, idx) => (
                      <span key={idx} className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-2.5 py-1 rounded-lg text-xs font-mono text-slate-800 dark:text-slate-200">
                        {val}
                      </span>
                    ))}
                    {activeCol.uniqueCount > 15 && (
                      <span className="text-slate-400 text-xs py-1 italic">
                        + {activeCol.uniqueCount - 15} more unique categories
                      </span>
                    )}
                  </div>
                </div>
              </div>
            )}
          </GlassCard>

          {/* Quick Stats Summary Ring */}
          <GlassCard id="completeness-summary" glowColor="green">
            <h4 className="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center space-x-2">
              <Percent className="w-5 h-5 text-emerald-500" />
              <span>Completeness & Size</span>
            </h4>
            <div className="space-y-4 text-xs">
              <div className="flex justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                <span className="text-slate-500">Memory Allocated:</span>
                <strong className="font-mono">{parseFloat((activeCol.memoryUsageBytes / 1024).toFixed(2))} KB</strong>
              </div>
              <div className="flex justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                <span className="text-slate-500">Missing Count:</span>
                <strong className="text-amber-600 dark:text-amber-400">{activeCol.missingCount} records</strong>
              </div>
              <div className="flex justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                <span className="text-slate-500">Missing Percentage:</span>
                <strong className="text-amber-600 dark:text-amber-400">{activeCol.missingPercentage}%</strong>
              </div>
              <div className="flex justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                <span className="text-slate-500">Inferred DataType:</span>
                <strong className="text-pink-500 uppercase">{activeCol.type}</strong>
              </div>
              <div className="flex justify-between pb-2">
                <span className="text-slate-500">Valid/Clean Rows:</span>
                <strong className="text-emerald-500">{(filteredRows.length - activeCol.missingCount).toLocaleString()} rows</strong>
              </div>
            </div>
          </GlassCard>
        </div>
      )}

      {/* Missing Value Audit & Duplicate Detection */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Missing Values List */}
        <GlassCard id="missing-audit" className="border-pink-500/10">
          <h4 className="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center space-x-2">
            <Sigma className="w-5 h-5 text-pink-500" />
            <span>Missing Value Analysis (Sparsity)</span>
          </h4>
          <div className="space-y-3.5">
            {summary.columns.map((c) => (
              <div key={c.name} className="space-y-1 text-xs">
                <div className="flex justify-between font-mono">
                  <span className="text-slate-800 dark:text-slate-200 font-medium">{c.name}</span>
                  <span className="text-slate-500">
                    {c.missingCount} missing ({c.missingPercentage}%)
                  </span>
                </div>
                <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${c.missingPercentage}%` }}
                    className="bg-pink-500 h-full rounded-full transition-all duration-500"
                  />
                </div>
              </div>
            ))}
          </div>
        </GlassCard>

        {/* Duplicate Detection Card */}
        <GlassCard id="duplication-audit">
          <h4 className="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center space-x-2">
            <Copy className="w-5 h-5 text-emerald-500" />
            <span>Duplicate Records Analysis</span>
          </h4>
          
          <div className="space-y-4">
            <div className={`flex items-center space-x-3 p-4 rounded-xl border ${
              summary.duplicateCount > 0
                ? 'bg-amber-50 dark:bg-amber-950/20 border-amber-100 dark:border-amber-900/30 text-amber-800 dark:text-amber-200'
                : 'bg-emerald-50 dark:bg-emerald-950/20 border-emerald-100 dark:border-emerald-900/30 text-emerald-800 dark:text-emerald-200'
            }`}>
              {summary.duplicateCount > 0 ? (
                <ShieldAlert className="w-6 h-6 text-amber-500 shrink-0" />
              ) : (
                <CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0" />
              )}
              <div>
                <p className="text-sm font-semibold">
                  {summary.duplicateCount > 0 
                    ? `Warning: ${summary.duplicateCount.toLocaleString()} duplicate records identified!`
                    : 'Success: No duplicate records found.'}
                </p>
                <p className="text-xs opacity-85 mt-0.5">
                  Duplicates represent identical data across every feature column. This may indicate double reporting or data entry errors.
                </p>
              </div>
            </div>

            {summary.duplicateCount > 0 && duplicateSample.length > 0 && (
              <div className="space-y-2">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Duplicate Rows Sample</span>
                <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
                  {duplicateSample.map((item, idx) => (
                    <div key={idx} className="p-2.5 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-200/50 dark:border-slate-800/50 text-[10px] font-mono leading-relaxed">
                      <div className="text-pink-500 font-bold mb-1">Index #{item.index}</div>
                      <div className="text-slate-600 dark:text-slate-400 truncate">
                        {JSON.stringify(item.row)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </GlassCard>
      </div>
    </div>
  );
};
export default StatsSummary;
