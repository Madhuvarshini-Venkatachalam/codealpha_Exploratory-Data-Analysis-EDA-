import React, { useState } from 'react';
import { ColumnMetadata, DatasetSummary, BusinessQuestion } from '../types';
import GlassCard from './GlassCard';
import { FileDown, Clipboard, Check, Sparkles, Printer, FileText } from 'lucide-react';

interface ReportGeneratorProps {
  summary: DatasetSummary;
  questions: BusinessQuestion[];
  conclusions: string[];
  recommendations: string[];
}

export const ReportGenerator: React.FC<ReportGeneratorProps> = ({
  summary,
  questions,
  conclusions,
  recommendations
}) => {
  const [copied, setCopied] = useState<boolean>(false);

  // Generate Markdown text representation
  const generateMarkdown = (): string => {
    let md = `# Exploratory Data Analysis (EDA) Executive Report\n`;
    md += `**Dataset:** ${summary.fileName}\n`;
    md += `**Date of Evaluation:** ${new Date().toLocaleDateString()}\n`;
    md += `**Metadata:** ${summary.rowCount.toLocaleString()} rows, ${summary.columnCount} columns\n\n`;

    md += `## 1. Executive Summary & KPIs\n`;
    md += `- **Total Observations:** ${summary.rowCount.toLocaleString()} records\n`;
    md += `- **Features/Columns:** ${summary.columnCount}\n`;
    md += `- **Identical Duplicates:** ${summary.duplicateCount.toLocaleString()} rows\n`;
    md += `- **Inferred Memory Footprint:** ${parseFloat((summary.totalMemoryBytes / 1024).toFixed(2))} KB\n\n`;

    md += `## 2. Column Audit & Completeness\n`;
    summary.columns.forEach(col => {
      md += `### - ${col.name} (${col.type.toUpperCase()})\n`;
      md += `  - Unique cardinality: ${col.uniqueCount.toLocaleString()}\n`;
      md += `  - Missing count: ${col.missingCount} (${col.missingPercentage}%)\n`;
      if (col.type === 'numeric') {
        md += `  - Mean: ${col.mean || 'N/A'} | Median: ${col.median || 'N/A'} | Std Dev: ${col.stdDev || 'N/A'}\n`;
        md += `  - IQR bounds: [${col.q1 || 'N/A'} - ${col.q3 || 'N/A'}] | Outliers detected: ${col.outlierCount || 0}\n`;
      }
      md += `  - Sample Values: ${col.uniqueValues.slice(0, 5).join(', ')}\n\n`;
    });

    md += `## 3. Executive AI Conclusions\n`;
    if (conclusions.length > 0) {
      conclusions.forEach((pt, idx) => {
        md += `${idx + 1}. ${pt}\n`;
      });
    } else {
      md += `*No conclusions compiled. Run AI Consulting tab.*\n`;
    }
    md += `\n`;

    md += `## 4. Strategic Business Recommendations\n`;
    if (recommendations.length > 0) {
      recommendations.forEach((pt, idx) => {
        md += `${idx + 1}. ${pt}\n`;
      });
    } else {
      md += `*No strategic business recommendations compiled. Run AI Consulting tab.*\n`;
    }
    md += `\n`;

    md += `*Report compiled using Google AI Studio Build - Senior EDA Analyst Agent.*`;
    return md;
  };

  // Generate self-contained HTML file contents
  const generateHTMLReport = (): string => {
    const markdownText = generateMarkdown();
    const tableRows = summary.columns.map(c => `
      <tr>
        <td style="font-family: monospace; color: #db2777; font-weight: bold;">${c.name}</td>
        <td style="text-transform: uppercase; font-size: 11px; font-weight: bold;">${c.type}</td>
        <td>${c.uniqueCount.toLocaleString()}</td>
        <td style="color: ${c.missingCount > 0 ? '#b45309' : '#059669'}; font-weight: bold;">
          ${c.missingCount} (${c.missingPercentage}%)
        </td>
        <td>${c.mean !== undefined ? c.mean.toLocaleString() : 'N/A'}</td>
        <td>${c.stdDev !== undefined ? c.stdDev.toLocaleString() : 'N/A'}</td>
        <td style="color: ${c.outlierCount && c.outlierCount > 0 ? '#dc2626' : '#6b7280'};">
          ${c.outlierCount !== undefined ? c.outlierCount : '0'}
        </td>
      </tr>
    `).join('');

    const conclusionItems = conclusions.map((c, i) => `
      <div style="display: flex; gap: 15px; margin-bottom: 12px; font-size: 14px;">
        <span style="display: flex; align-items: center; justify-content: center; width: 24px; height: 24px; border-radius: 50%; background: #fdf2f8; border: 1px solid #fbcfe8; color: #db2777; font-weight: bold; flex-shrink: 0;">${i + 1}</span>
        <p style="margin: 0; line-height: 1.5; color: #374151;">${c}</p>
      </div>
    `).join('');

    const recommendationItems = recommendations.map((r, i) => `
      <div style="display: flex; gap: 15px; margin-bottom: 12px; font-size: 14px;">
        <span style="display: flex; align-items: center; justify-content: center; width: 24px; height: 24px; border-radius: 50%; background: #ecfdf5; border: 1px solid #a7f3d0; color: #059669; font-weight: bold; flex-shrink: 0;">${i + 1}</span>
        <p style="margin: 0; line-height: 1.5; color: #374151;">${r}</p>
      </div>
    `).join('');

    return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>EDA Audit Report - ${summary.fileName}</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      line-height: 1.6;
      color: #1f2937;
      background-color: #f9fafb;
      margin: 0;
      padding: 40px 20px;
    }
    .container {
      max-width: 900px;
      margin: 0 auto;
      background: white;
      border-radius: 16px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
      border: 1px solid #e5e7eb;
      padding: 40px;
    }
    .header {
      border-bottom: 2px solid #ec4899;
      padding-bottom: 20px;
      margin-bottom: 30px;
    }
    .header h1 {
      margin: 0;
      font-size: 28px;
      color: #111827;
      letter-spacing: -0.5px;
    }
    .meta-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 15px;
      margin-bottom: 30px;
    }
    .meta-card {
      background: #fdf2f8;
      border: 1px solid #fbcfe8;
      border-radius: 12px;
      padding: 15px;
      text-align: center;
    }
    .meta-card.green {
      background: #ecfdf5;
      border: 1px solid #a7f3d0;
    }
    .meta-card h3 {
      margin: 0;
      font-size: 20px;
      color: #111827;
    }
    .meta-card p {
      margin: 5px 0 0 0;
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #6b7280;
      font-weight: bold;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 20px 0;
      font-size: 13px;
    }
    th, td {
      padding: 12px;
      text-align: left;
      border-bottom: 1px solid #e5e7eb;
    }
    th {
      background: #f3f4f6;
      color: #374151;
      text-transform: uppercase;
      font-size: 11px;
      letter-spacing: 0.5px;
    }
    .grid-2 {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 30px;
      margin-top: 35px;
    }
    .section-title {
      border-bottom: 1px solid #e5e7eb;
      padding-bottom: 8px;
      margin-bottom: 15px;
      color: #111827;
      font-size: 18px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Exploratory Data Analysis (EDA) Report</h1>
      <p style="margin: 5px 0 0 0; color: #6b7280; font-size: 14px;">
        Dataset File Name: <strong>${summary.fileName}</strong> | Processed: ${new Date().toLocaleDateString()}
      </p>
    </div>

    <div class="meta-grid">
      <div class="meta-card">
        <h3>${summary.rowCount.toLocaleString()}</h3>
        <p>Total Rows</p>
      </div>
      <div class="meta-card green">
        <h3>${summary.columnCount}</h3>
        <p>Total Columns</p>
      </div>
      <div class="meta-card">
        <h3>${summary.duplicateCount.toLocaleString()}</h3>
        <p>Duplicate Rows</p>
      </div>
      <div class="meta-card green">
        <h3>${parseFloat((summary.totalMemoryBytes / 1024).toFixed(1))} KB</h3>
        <p>Calculated Footprint</p>
      </div>
    </div>

    <h2 class="section-title">Column Properties & Statistical Audit</h2>
    <table>
      <thead>
        <tr>
          <th>Column Name</th>
          <th>Type</th>
          <th>Unique Count</th>
          <th>Missing Values</th>
          <th>Mean (μ)</th>
          <th>Std Dev (σ)</th>
          <th>Outliers</th>
        </tr>
      </thead>
      <tbody>
        ${tableRows}
      </tbody>
    </table>

    <div class="grid-2">
      <div>
        <h2 class="section-title" style="color: #db2777;">Executive AI Conclusions</h2>
        ${conclusionItems || '<p style="color:#9ca3af; font-style:italic;">No overall conclusions generated.</p>'}
      </div>
      <div>
        <h2 class="section-title" style="color: #059669;">Strategic Recommendations</h2>
        ${recommendationItems || '<p style="color:#9ca3af; font-style:italic;">No strategic recommendations generated.</p>'}
      </div>
    </div>

    <div style="margin-top: 40px; text-align: center; font-size: 11px; color: #9ca3af; border-top: 1px solid #e5e7eb; padding-top: 20px;">
      Report automatically generated by Exploratory Data Analysis AI Suite - Google AI Studio Build.
    </div>
  </div>
</body>
</html>
    `;
  };

  const handleDownloadHTML = () => {
    const htmlContent = generateHTMLReport();
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `EDA_Report_${summary.fileName.replace(/\.[^/.]+$/, "")}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopyMarkdown = () => {
    const md = generateMarkdown();
    navigator.clipboard.writeText(md);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div id="report-generator-container" className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Card Summary Left */}
        <GlassCard id="report-meta-card" className="lg:col-span-1">
          <h4 className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-4">Report Builder Configuration</h4>
          <div className="space-y-4">
            <div className="p-3 bg-slate-50 dark:bg-slate-900/40 border border-slate-150 dark:border-slate-800 rounded-xl">
              <span className="text-[10px] text-slate-400 block font-semibold uppercase">Target Dataset</span>
              <strong className="text-xs truncate block mt-0.5">{summary.fileName}</strong>
            </div>

            <div className="space-y-2 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              <p>
                Our report bundle groups all structural descriptors, missing percentages, outliers, correlation Heatmaps, and server-side strategic AI summaries into a clean format.
              </p>
              <p>
                Download the fully compiled, beautiful glassmorphic HTML file to open offline in any browser, or copy standard markdown to paste directly into word editors.
              </p>
            </div>

            <div className="space-y-2 pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={handleDownloadHTML}
                className="w-full py-2.5 bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white text-xs font-bold rounded-xl flex items-center justify-center space-x-2 shadow-md shadow-pink-500/25 cursor-pointer active:scale-98 transition"
              >
                <FileDown className="w-4 h-4" />
                <span>Download Interactive HTML</span>
              </button>

              <button
                onClick={handleCopyMarkdown}
                className="w-full py-2.5 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-center space-x-2 cursor-pointer active:scale-98 transition"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Clipboard className="w-4 h-4" />}
                <span>{copied ? 'Markdown Copied!' : 'Copy Markdown Summary'}</span>
              </button>

              <button
                onClick={handlePrint}
                className="w-full py-2.5 bg-transparent hover:bg-slate-50 dark:hover:bg-slate-900/30 text-slate-500 dark:text-slate-400 text-xs font-bold rounded-xl flex items-center justify-center space-x-2 cursor-pointer transition"
              >
                <Printer className="w-4 h-4" />
                <span>Print Document</span>
              </button>
            </div>
          </div>
        </GlassCard>

        {/* Live Preview Paper Box Right */}
        <GlassCard id="report-paper-preview" glowColor="none" className="lg:col-span-2">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4 text-slate-900 dark:text-white">
            <h4 className="text-sm font-bold uppercase tracking-wider flex items-center space-x-1.5">
              <FileText className="w-4.5 h-4.5 text-pink-500" />
              <span>Report Draft Preview</span>
            </h4>
            <span className="text-[10px] px-2.5 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-bold rounded-full">
              DRAFT
            </span>
          </div>

          <div className="bg-slate-50 dark:bg-slate-950/40 rounded-xl p-5 border border-slate-150 dark:border-slate-850 h-[450px] overflow-y-auto font-mono text-[11px] leading-relaxed text-slate-700 dark:text-slate-400 select-all">
            <pre className="whitespace-pre-wrap">{generateMarkdown()}</pre>
          </div>
        </GlassCard>
      </div>
    </div>
  );
};
export default ReportGenerator;
