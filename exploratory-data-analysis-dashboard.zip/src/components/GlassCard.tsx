import React from 'react';
import { motion } from 'motion/react';

interface GlassCardProps {
  children: React.ReactNode;
  id?: string;
  className?: string;
  hoverEffect?: boolean;
  onClick?: () => void;
  glowColor?: 'pink' | 'green' | 'none';
}

export const GlassCard: React.FC<GlassCardProps> = ({
  children,
  id,
  className = '',
  hoverEffect = true,
  onClick,
  glowColor = 'none'
}) => {
  const glowStyles = {
    pink: 'shadow-[0_0_15px_-3px_rgba(236,72,153,0.15)] border-pink-500/20 dark:border-pink-500/30',
    green: 'shadow-[0_0_15px_-3px_rgba(16,185,129,0.15)] border-emerald-500/20 dark:border-emerald-500/30',
    none: 'border-slate-200/50 dark:border-slate-800/50 shadow-sm'
  };

  return (
    <motion.div
      id={id}
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: 'easeOut' }}
      whileHover={hoverEffect ? { y: -3, scale: 1.005 } : undefined}
      onClick={onClick}
      className={`
        relative backdrop-blur-md rounded-2xl border bg-white/70 dark:bg-slate-900/60
        transition-all duration-300
        ${glowStyles[glowColor]}
        ${onClick ? 'cursor-pointer hover:bg-white/80 dark:hover:bg-slate-900/85' : ''}
        ${className}
      `}
    >
      {/* Decorative inner glow for pink/green */}
      {glowColor === 'pink' && (
        <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-pink-500/5 to-transparent pointer-events-none" />
      )}
      {glowColor === 'green' && (
        <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-emerald-500/5 to-transparent pointer-events-none" />
      )}
      <div className="relative z-10 h-full p-5">
        {children}
      </div>
    </motion.div>
  );
};
export default GlassCard;
