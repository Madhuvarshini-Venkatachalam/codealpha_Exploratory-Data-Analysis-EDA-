import React, { useState } from 'react';
import { ColumnMetadata, DatasetSummary } from '../types';
import GlassCard from './GlassCard';
import { HelpCircle, TrendingUp, AlertOctagon, RefreshCw, Layers } from 'lucide-react';

interface AdvancedAnalyticsProps {
  summary: DatasetSummary;
}

export const AdvancedAnalytics: React.FC<AdvancedAnalyticsProps> = ({ summary }) => {
  const numericCols = summary.columns.filter(c => c.type === 'numeric');
  const [outlierCol, setOutlierCol] = useState<string>(numericCols[0]?.name || '');

  const activeOutlierMeta = numericCols.find(c => c.name === outlierCol);

  // Helper to color the correlation cells
  const getCorrelationColorClass = (val: number) => {
    if (val > 0.7) return 'bg-pink-600 text-white';
    if (val > 0.4) return 'bg-pink-500/80 text-white';
    if (val > 0.1) return 'bg-pink-300/30 text-slate-800 dark:text-slate-200';
    if (val < -0.7) return 'bg-emerald-600 text-white';
    if (val < -0.4) return 'bg-emerald-500/80 text-white';
    if (val < -0.1) return 'bg-emerald-300/30 text-slate-800 dark:text-slate-200';
    return 'bg-slate-50 dark:bg-slate-900/40 text-slate-400 dark:text-slate-500';
  };

  return (
    <div id="advanced-analytics-container" className="space-y-6">
      {/* Correlation Matrix Heatmap */}
      <GlassCard id="correlation-card" glowColor="none">
        <div className="flex justify-between items-start border-b border-slate-100 dark:border-slate-800 pb-4 mb-4">
          <div>
            <span className="text-[10px] uppercase font-bold tracking-widest text-pink-500">Feature Relationships</span>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">Interactive Pearson Correlation Heatmap</h3>
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center space-x-1">
            <Layers className="w-4 h-4 text-emerald-500 animate-pulse" />
            <span>Auto-Calculated Coefficients (-1 to +1)</span>
          </div>
        </div>

        {numericCols.length < 2 ? (
          <div className="py-12 text-center text-slate-400 dark:text-slate-500">
            At least 2 numeric columns are required to run a bivariate Pearson correlation analysis.
          </div>
        ) : (
          <div className="space-y-6">
            <div className="overflow-x-auto p-1">
              <div className="min-w-[600px]">
                {/* Heatmap Grid */}
                <div className="grid border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden" style={{ gridTemplateColumns: `repeat(${numericCols.length + 1}, minmax(0, 1fr))` }}>
                  {/* Empty top corner block */}
                  <div className="bg-slate-100/60 dark:bg-slate-950/40 p-3 font-semibold text-xs text-slate-500 dark:text-slate-400 border-r border-b border-slate-200 dark:border-slate-800 truncate">
                    Columns Heatmap
                  </div>

                  {/* Top Headers */}
                  {numericCols.map(col => (
                    <div key={col.name} className="bg-slate-100/60 dark:bg-slate-950/40 p-3 font-mono font-medium text-[10px] text-pink-600 dark:text-pink-400 border-r border-b border-slate-200 dark:border-slate-800 truncate text-center" title={col.name}>
                      {col.name}
                    </div>
                  ))}

                  {/* Rows */}
                  {numericCols.map(rowCol => (
                    <React.Fragment key={rowCol.name}>
                      {/* Left header column */}
                      <div className="bg-slate-100/60 dark:bg-slate-950/40 p-3 font-mono font-medium text-[10px] text-pink-600 dark:text-pink-400 border-r border-b border-slate-200 dark:border-slate-800 truncate" title={rowCol.name}>
                        {rowCol.name}
                      </div>

                      {/* Values */}
                      {numericCols.map(col => {
                        const cell = summary.correlationMatrix.find(
                          m => (m.col1 === rowCol.name && m.col2 === col.name) || (m.col1 === col.name && m.col2 === rowCol.name)
                        );
                        const value = cell ? cell.value : 0;
                        
                        return (
                          <div
                            key={col.name}
                            className={`
                              p-3 text-center font-mono font-bold text-xs border-r border-b border-slate-200 dark:border-slate-800 transition-all duration-200 hover:scale-[1.03] hover:shadow-md cursor-help relative group
                              ${getCorrelationColorClass(value)}
                            `}
                          >
                            {value.toFixed(2)}

                            {/* Tooltip detail */}
                            <div className="absolute z-50 bottom-full left-1/2 -translate-x-1/2 mb-1.5 hidden group-hover:block w-48 p-2 bg-slate-950 text-white rounded-lg text-[10px] font-sans font-normal leading-normal text-left shadow-xl pointer-events-none border border-slate-800">
                              <p className="font-bold border-b border-slate-800 pb-1 mb-1 text-pink-400">Pearson Coefficient</p>
                              <p><strong className="text-slate-300">X:</strong> {rowCol.name}</p>
                              <p><strong className="text-slate-300">Y:</strong> {col.name}</p>
                              <p className="font-bold text-emerald-400 mt-1">Value: {value}</p>
                            </div>
                          </div>
                        );
                      })}
                    </React.Fragment>
                  ))}
                </div>
              </div>
            </div>

            {/* Heatmap Legend */}
            <div className="flex flex-wrap items-center gap-6 justify-center text-xs p-3 bg-slate-50 dark:bg-slate-950/30 rounded-xl border border-slate-150 dark:border-slate-800/60">
              <span className="text-slate-500 font-semibold uppercase tracking-wider">Correlation Strength:</span>
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 bg-pink-600 rounded" />
                <span className="text-slate-700 dark:text-slate-300">Positive (&gt;0.7)</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 bg-pink-400/40 rounded" />
                <span className="text-slate-700 dark:text-slate-300">Moderate Positive (0.1 - 0.6)</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 bg-slate-100 dark:bg-slate-800 rounded border border-slate-300" />
                <span className="text-slate-700 dark:text-slate-300">Neutral/No Link</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 bg-emerald-400/40 rounded" />
                <span className="text-slate-700 dark:text-slate-300">Moderate Negative (-0.1 - -0.6)</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 bg-emerald-600 rounded" />
                <span className="text-slate-700 dark:text-slate-300">Negative (&lt;-0.7)</span>
              </div>
            </div>
          </div>
        )}
      </GlassCard>

      {/* Outlier Profiling section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Outlier controls */}
        <GlassCard id="outlier-picker">
          <h4 className="text-sm font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3">
            Outliers Target Variable
          </h4>
          <div className="space-y-2">
            {numericCols.map(c => (
              <button
                key={c.name}
                onClick={() => setOutlierCol(c.name)}
                className={`
                  w-full text-left px-3 py-2.5 rounded-xl text-xs font-mono font-medium transition flex justify-between items-center cursor-pointer
                  ${outlierCol === c.name
                    ? 'bg-gradient-to-r from-pink-500 to-pink-600 text-white shadow-sm shadow-pink-500/20'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-pink-500/30'
                  }
                `}
              >
                <span>{c.name}</span>
                <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                  outlierCol === c.name 
                    ? 'bg-white/20 text-white' 
                    : (c.outlierCount || 0) > 0 
                    ? 'bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400' 
                    : 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600'
                }`}>
                  {c.outlierCount || 0} outliers
                </span>
              </button>
            ))}
          </div>
        </GlassCard>

        {/* Outlier display */}
        <GlassCard id="outliers-summary" glowColor="pink" className="lg:col-span-2">
          {activeOutlierMeta ? (
            <div className="space-y-4">
              <div className="flex justify-between items-start border-b border-slate-100 dark:border-slate-800 pb-3">
                <div>
                  <span className="text-[10px] uppercase font-bold tracking-widest text-pink-500">IQR (Tukey's Fence) Audit</span>
                  <h4 className="text-base font-bold font-mono text-slate-900 dark:text-white mt-0.5">
                    Anomalies: {activeOutlierMeta.name}
                  </h4>
                </div>
                <div className={`px-3 py-1 rounded-full text-xs font-semibold flex items-center space-x-1.5 ${
                  (activeOutlierMeta.outlierCount || 0) > 0
                    ? 'bg-amber-50 dark:bg-amber-950/20 text-amber-600 border border-amber-100 dark:border-amber-900/30'
                    : 'bg-emerald-50 dark:bg-emerald-950/20 text-emerald-500 border border-emerald-100 dark:border-emerald-900/30'
                }`}>
                  <AlertOctagon className="w-4 h-4" />
                  <span>{activeOutlierMeta.outlierCount || 0} Outliers Detected</span>
                </div>
              </div>

              {/* Statistical Bounds */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-2.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                  <span className="text-[10px] text-slate-400 font-semibold block uppercase">Q1 (25%)</span>
                  <strong className="font-mono text-slate-800 dark:text-slate-200">{activeOutlierMeta.q1}</strong>
                </div>
                <div className="p-2.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                  <span className="text-[10px] text-slate-400 font-semibold block uppercase">Q3 (75%)</span>
                  <strong className="font-mono text-slate-800 dark:text-slate-200">{activeOutlierMeta.q3}</strong>
                </div>
                <div className="p-2.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                  <span className="text-[10px] text-slate-400 font-semibold block uppercase">Lower Fence</span>
                  <strong className="font-mono text-red-500">
                    {parseFloat(((activeOutlierMeta.q1 || 0) - 1.5 * (activeOutlierMeta.iqr || 0)).toFixed(3))}
                  </strong>
                </div>
                <div className="p-2.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                  <span className="text-[10px] text-slate-400 font-semibold block uppercase">Upper Fence</span>
                  <strong className="font-mono text-red-500">
                    {parseFloat(((activeOutlierMeta.q3 || 0) + 1.5 * (activeOutlierMeta.iqr || 0)).toFixed(3))}
                  </strong>
                </div>
              </div>

              {/* List of Outliers */}
              {(activeOutlierMeta.outlierCount || 0) > 0 ? (
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Sample Outlier Records (Sorted Deviation)</span>
                  <div className="flex flex-wrap gap-1.5 max-h-[140px] overflow-y-auto p-1.5 bg-slate-50 dark:bg-slate-900/30 border border-slate-150 dark:border-slate-800 rounded-xl">
                    {activeOutlierMeta.outliers?.map((val, idx) => (
                      <span
                        key={idx}
                        className="bg-red-50 dark:bg-red-950/20 border border-red-100 dark:border-red-900/30 text-red-600 dark:text-red-400 px-2.5 py-1 rounded-lg text-xs font-mono font-semibold hover:bg-red-100 transition"
                      >
                        {val}
                      </span>
                    ))}
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
                    * Tukey outliers lie outside the 1.5 × IQR boundary fence. In standard business reporting, these are frequently audited for data entry typos or flagged as special transaction groupings (VIP customers, extraordinary charges, seasonality spikes).
                  </p>
                </div>
              ) : (
                <div className="py-8 text-center text-xs text-slate-400 dark:text-slate-500 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
                  Wonderful! Standard outlier checks find no records with high standard deviation from normal ranges in {activeOutlierMeta.name}.
                </div>
              )}
            </div>
          ) : (
            <div className="py-12 text-center text-slate-400 dark:text-slate-500">
              No numeric features found to run IQR Tukey outlier detection.
            </div>
          )}
        </GlassCard>
      </div>
    </div>
  );
};
export default AdvancedAnalytics;
