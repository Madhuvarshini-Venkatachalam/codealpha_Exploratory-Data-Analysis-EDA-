import React, { useState, useMemo } from 'react';
import { DatasetSummary } from '../types';
import GlassCard from './GlassCard';
import { ResponsiveContainer, ComposedChart, Line, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Area } from 'recharts';
import { TrendingUp, Award, Settings, BarChart2, CheckCircle, Info, Sparkles } from 'lucide-react';

interface AiPredictiveForecasterProps {
  summary: DatasetSummary;
}

export const AiPredictiveForecaster: React.FC<AiPredictiveForecasterProps> = ({ summary }) => {
  // Get all numeric columns
  const numericColumns = useMemo(() => {
    return summary.columns.filter(c => c.type === 'numeric');
  }, [summary.columns]);

  // State for selectors
  const [targetColumn, setTargetColumn] = useState<string>(() => {
    return numericColumns[0]?.name || '';
  });
  const [predictorColumn, setPredictorColumn] = useState<string>(() => {
    // Try to find a different column, or default to "Index"
    const secondCol = numericColumns.find(c => c.name !== numericColumns[0]?.name);
    return secondCol?.name || '_index';
  });

  const [forecastHorizon, setForecastHorizon] = useState<number>(10);
  const [loadingAiDiagnostic, setLoadingAiDiagnostic] = useState(false);
  const [aiDiagnostic, setAiDiagnostic] = useState<string>('');

  // Run OLS Regression & Projection Calculations
  const analyticsResult = useMemo(() => {
    if (!targetColumn) return null;

    const rows = summary.allRows;
    if (rows.length < 3) return null;

    // Build the data array
    const xRaw: number[] = [];
    const yRaw: number[] = [];
    const validPairs: { x: number; y: number; index: number }[] = [];

    rows.forEach((row, idx) => {
      let yVal = Number(row[targetColumn]);
      let xVal = idx; // fallback index

      if (predictorColumn !== '_index') {
        xVal = Number(row[predictorColumn]);
      }

      if (!isNaN(yVal) && !isNaN(xVal) && yVal !== null && xVal !== null) {
        xRaw.push(xVal);
        yRaw.push(yVal);
        validPairs.push({ x: xVal, y: yVal, index: idx });
      }
    });

    if (validPairs.length < 3) return null;

    // Sort valid pairs by X value for plotting
    validPairs.sort((a, b) => a.x - b.x);

    const n = validPairs.length;
    let sumX = 0;
    let sumY = 0;
    let sumXY = 0;
    let sumXX = 0;
    let sumYY = 0;

    validPairs.forEach(p => {
      sumX += p.x;
      sumY += p.y;
      sumXY += p.x * p.y;
      sumXX += p.x * p.x;
      sumYY += p.y * p.y;
    });

    const meanX = sumX / n;
    const meanY = sumY / n;

    // Linear Regression parameters
    const numerator = sumXY - (sumX * sumY) / n;
    const denominator = sumXX - (sumX * sumX) / n;

    // If denominator is zero (all X same), slope is zero
    const slope = denominator !== 0 ? numerator / denominator : 0;
    const intercept = meanY - slope * meanX;

    // Calculate metrics: R-squared, MSE, MAPE
    let totalSS = 0; // Sum of Squares Total
    let residualSS = 0; // Sum of Squares Residual
    let absolutePercentageSum = 0;

    validPairs.forEach(p => {
      const predicted = slope * p.x + intercept;
      const actual = p.y;

      totalSS += Math.pow(actual - meanY, 2);
      residualSS += Math.pow(actual - predicted, 2);

      if (actual !== 0) {
        absolutePercentageSum += Math.abs((actual - predicted) / actual);
      }
    });

    const rSquared = totalSS !== 0 ? 1 - residualSS / totalSS : 0;
    const mse = residualSS / n;
    const rmse = Math.sqrt(mse);
    const mape = n > 0 ? (absolutePercentageSum / n) * 100 : 0;

    // Simple Estimate of Standard Error of Regression
    const stdErrReg = n > 2 ? Math.sqrt(residualSS / (n - 2)) : 0;

    // Create chart points for Recharts
    const chartData: any[] = [];

    // Add historical actuals and fitted line
    validPairs.forEach(p => {
      const fitted = slope * p.x + intercept;
      chartData.push({
        x: p.x,
        actual: p.y,
        trend: parseFloat(fitted.toFixed(4)),
        isForecast: false
      });
    });

    // Generate forecast projection
    const xMax = validPairs[validPairs.length - 1].x;
    const xMin = validPairs[0].x;
    const xRange = xMax - xMin || 1;
    const stepSize = xRange / n;

    // Add projected future steps
    const forecastPoints: any[] = [];
    for (let i = 1; i <= forecastHorizon; i++) {
      const forecastX = xMax + i * (predictorColumn === '_index' ? 1 : stepSize);
      const predictedY = slope * forecastX + intercept;

      // Confidence margin (95% interval approximation using standard errors)
      const margin = 1.96 * stdErrReg * Math.sqrt(1 + 1/n + Math.pow(forecastX - meanX, 2) / (sumXX - n * Math.pow(meanX, 2) || 1));
      
      forecastPoints.push({
        x: parseFloat(forecastX.toFixed(2)),
        forecast: parseFloat(predictedY.toFixed(4)),
        lowerConf: parseFloat((predictedY - margin).toFixed(4)),
        upperConf: parseFloat((predictedY + margin).toFixed(4)),
        isForecast: true
      });
    }

    const fullChartData = [...chartData, ...forecastPoints];

    return {
      fullChartData,
      slope,
      intercept,
      rSquared,
      rmse,
      mape,
      sampleSize: n,
      predictorName: predictorColumn === '_index' ? 'Row Index' : predictorColumn,
      targetName: targetColumn
    };
  }, [summary, targetColumn, predictorColumn, forecastHorizon]);

  // Dynamic AI Analytical Insights Explanation
  const generatedDiagnosticText = useMemo(() => {
    if (!analyticsResult) return '';

    const { slope, rSquared, mape, predictorName, targetName } = analyticsResult;
    const direction = slope > 0 ? 'upward' : slope < 0 ? 'downward' : 'flat';
    const strength = rSquared > 0.7 ? 'exceptionally strong' : rSquared > 0.4 ? 'moderately reliable' : 'low-predictive or volatile';
    const accuracyGrade = mape < 5 ? 'excellent (<5% deviation)' : mape < 15 ? 'acceptable (5-15% deviation)' : 'highly irregular';

    return `### 📈 Statistical Predictive Report
The OLS forecasting model indicates a **${direction} trend** projecting the behavior of **${targetName}** based on **${predictorName}**. 

#### 🔑 Model Parameters
- **Directional Velocity (Slope)**: \`${slope.toFixed(4)}\` unit change per step.
- **Goodness-of-Fit ($R^2$)**: \`${rSquared.toFixed(4)}\` (${(rSquared * 100).toFixed(1)}% of variance explained). The predictive baseline is considered **${strength}**.
- **Model Precision (MAPE)**: \`${mape.toFixed(2)}%\` which represents a **${accuracyGrade}** statistical accuracy level.

#### 💡 Strategic Business Implication
1. **Capacity & Planning**: Since the trend is **${direction}**, long-range planning should budget for ${slope > 0 ? 'increasing constraints and scale capacity requirements' : 'diminished volume and consolidation of resources'}.
2. **Volatilities**: Given the R-squared index, the model recommends ${rSquared < 0.4 ? 'introducing other causal indicators (multi-variable models) due to high local variances' : 'relying on this baseline for mid-term budgeting and goal setting'}.
3. **Imputation Safeguard**: Standard margins of uncertainty enlarge as we progress further along the forecast horizon. Monitor the outer prediction intervals (the shaded corridor) for worst-case planning.`;
  }, [analyticsResult]);

  const fetchAiDiagnostic = async () => {
    if (!analyticsResult) return;
    setLoadingAiDiagnostic(true);
    try {
      const response = await fetch('/api/eda/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileName: summary.fileName,
          columns: summary.columns.map(c => ({ name: c.name, type: c.type })),
          sampleData: summary.sampleRows.slice(0, 3),
          rowCount: summary.rowCount,
          userQuestion: `You are an elite econometrician. Write a highly professional statistical evaluation of this OLS forecasting run:
Target Column: ${analyticsResult.targetName}
Predictor Column: ${analyticsResult.predictorName}
Slope: ${analyticsResult.slope.toFixed(5)}
Intercept: ${analyticsResult.intercept.toFixed(5)}
R-squared (R2): ${analyticsResult.rSquared.toFixed(5)}
MAPE: ${analyticsResult.mape.toFixed(2)}%
Sample Size: ${analyticsResult.sampleSize} rows.

Provide:
1. Economic or physical interpretation of the slope.
2. Critique of the R2 strength of fit.
3. 2 McKinsey-style strategic action points the business should take regarding this projected trajectory.`
        })
      });
      const data = await response.json();
      setAiDiagnostic(data.answer || '');
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingAiDiagnostic(false);
    }
  };

  if (numericColumns.length === 0) {
    return (
      <GlassCard id="no-numeric-forecast" className="text-center py-10 border-pink-500/10">
        <Info className="w-10 h-10 text-pink-500 mx-auto mb-3" />
        <h4 className="text-base font-bold text-slate-800 dark:text-white">Predictive Modeling Unavailable</h4>
        <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto leading-relaxed">
          Predictive modeling requires at least one numeric column to construct regression slopes and trendlines. Upload a dataset containing quantitative variables to unlock.
        </p>
      </GlassCard>
    );
  }

  return (
    <div id="predictive-modeler-root" className="space-y-6">
      {/* Controls Card */}
      <GlassCard id="forecast-controls" glowColor="pink" className="border-pink-500/10 p-5">
        <div className="flex items-center space-x-2 text-pink-500 mb-4">
          <Settings className="w-5 h-5 text-pink-500" />
          <h4 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">Model Configuration Settings</h4>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="text-[10px] uppercase font-bold tracking-widest text-slate-500 dark:text-slate-400 block mb-1.5">
              Target Variable (Y)
            </label>
            <select
              value={targetColumn}
              onChange={(e) => setTargetColumn(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-pink-500 focus:border-pink-500"
            >
              {numericColumns.map(c => (
                <option key={c.name} value={c.name}>{c.name} (numeric)</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[10px] uppercase font-bold tracking-widest text-slate-500 dark:text-slate-400 block mb-1.5">
              Predictor Variable (X)
            </label>
            <select
              value={predictorColumn}
              onChange={(e) => setPredictorColumn(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-pink-500 focus:border-pink-500"
            >
              <option value="_index">Synthetic Row Index (Sequence)</option>
              {numericColumns.map(c => (
                <option key={c.name} value={c.name}>{c.name} (numeric)</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[10px] uppercase font-bold tracking-widest text-slate-500 dark:text-slate-400 block mb-1.5">
              Forecast Steps Horizon
            </label>
            <input
              type="number"
              min={1}
              max={50}
              value={forecastHorizon}
              onChange={(e) => setForecastHorizon(Math.min(50, Math.max(1, parseInt(e.target.value) || 10)))}
              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-pink-500"
            />
          </div>

          <div className="flex items-end">
            <button
              onClick={fetchAiDiagnostic}
              disabled={loadingAiDiagnostic}
              className="w-full py-2 bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white text-xs font-bold rounded-xl flex items-center justify-center space-x-1.5 shadow-lg shadow-pink-500/20 cursor-pointer disabled:opacity-50 transition hover:scale-[1.02] active:scale-95"
            >
              <Sparkles className={`w-4 h-4 ${loadingAiDiagnostic ? 'animate-spin' : ''}`} />
              <span>{loadingAiDiagnostic ? 'Refining Model...' : 'Trigger Econometric AI'}</span>
            </button>
          </div>
        </div>
      </GlassCard>

      {analyticsResult ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Chart Card */}
          <div className="lg:col-span-2">
            <GlassCard id="forecast-visualization" glowColor="pink" className="border-pink-500/10 flex flex-col justify-between h-full p-5">
              <div>
                <h5 className="text-sm font-bold text-slate-900 dark:text-white mb-1 flex items-center space-x-1.5">
                  <BarChart2 className="w-4.5 h-4.5 text-pink-500" />
                  <span>Interactive Predictive Composite Chart</span>
                </h5>
                <p className="text-[11px] text-slate-400 leading-normal mb-6">
                  Points represent historical samples. The purple line shows the historical trend, extending as a dashed corridor with shaded standard boundaries (95% prediction confidence) for future forecast periods.
                </p>
              </div>

              <div className="h-[280px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={analyticsResult.fullChartData} margin={{ top: 10, right: 15, left: -10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-slate-100 dark:stroke-slate-900" />
                    <XAxis
                      dataKey="x"
                      type="number"
                      domain={['auto', 'auto']}
                      tick={{ fill: '#94a3b8', fontSize: 10 }}
                      label={{ value: analyticsResult.predictorName, position: 'insideBottom', offset: -5, fill: '#64748b', fontSize: 10 }}
                    />
                    <YAxis tick={{ fill: '#94a3b8', fontSize: 10 }} />
                    <Tooltip
                      contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', borderRadius: '12px', border: '1px solid rgba(244, 63, 94, 0.2)', padding: '10px' }}
                      labelFormatter={(label) => `X: ${label}`}
                      formatter={(value: any, name: string) => {
                        if (name === 'actual') return [`${Number(value).toFixed(2)}`, 'Historical Actual'];
                        if (name === 'trend') return [`${Number(value).toFixed(2)}`, 'Historical Fitted Trend'];
                        if (name === 'forecast') return [`${Number(value).toFixed(2)}`, 'Projected Forecast'];
                        if (name === 'upperConf') return [`${Number(value).toFixed(2)}`, 'Upper confidence bound'];
                        if (name === 'lowerConf') return [`${Number(value).toFixed(2)}`, 'Lower confidence bound'];
                        return [value, name];
                      }}
                    />
                    <Legend verticalAlign="top" height={36} wrapperStyle={{ fontSize: '10px' }} />
                    
                    {/* Confidence band for forecast */}
                    <Area
                      name="Confidence Range"
                      dataKey="upperConf"
                      stroke="none"
                      fill="rgba(244, 63, 94, 0.08)"
                      activeDot={false}
                    />
                    <Area
                      name="Confidence corridor"
                      dataKey="lowerConf"
                      stroke="none"
                      fill="transparent"
                      activeDot={false}
                    />

                    {/* Historical points as scatter */}
                    <Scatter name="Historical Actual" dataKey="actual" fill="#10b981" line={false} shape="circle" size={40} />

                    {/* Linear trendline fitted */}
                    <Line name="Historical Fitted Trend" type="monotone" dataKey="trend" stroke="#f43f5e" strokeWidth={2} dot={false} strokeDasharray="1 1" />

                    {/* Future Projection Forecast dashed */}
                    <Line name="Projected Forecast" type="monotone" dataKey="forecast" stroke="#f43f5e" strokeWidth={2.5} dot={true} strokeDasharray="5 5" />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            </GlassCard>
          </div>

          {/* Model Statistics & AI Insights */}
          <div className="lg:col-span-1 space-y-4">
            {/* OLS metrics card */}
            <GlassCard id="model-metrics" className="p-4">
              <h5 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3 flex items-center space-x-1">
                <Award className="w-4 h-4 text-emerald-500" />
                <span>Goodness-of-Fit Performance</span>
              </h5>

              <div className="space-y-3.5">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-900">
                  <span className="text-xs text-slate-500">Goodness-of-Fit (R²)</span>
                  <span className="font-mono text-xs font-bold text-slate-800 dark:text-white">
                    {analyticsResult.rSquared.toFixed(4)}
                  </span>
                </div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-900">
                  <span className="text-xs text-slate-500">Root Mean Squared Error (RMSE)</span>
                  <span className="font-mono text-xs font-bold text-slate-800 dark:text-white">
                    {analyticsResult.rmse.toLocaleString([], { maximumFractionDigits: 4 })}
                  </span>
                </div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-900">
                  <span className="text-xs text-slate-500">Average Percentage Error (MAPE)</span>
                  <span className="font-mono text-xs font-bold text-slate-800 dark:text-white">
                    {analyticsResult.mape.toFixed(2)}%
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-500">Slope Coefficient (m)</span>
                  <span className="font-mono text-xs font-bold text-pink-500">
                    {analyticsResult.slope > 0 ? '+' : ''}{analyticsResult.slope.toFixed(4)}
                  </span>
                </div>
              </div>
            </GlassCard>

            {/* AI Diagnostics response panel */}
            <GlassCard id="ai-econometrics-insight" className="border-pink-500/10 flex-1 p-4">
              <div className="flex items-center space-x-1 text-pink-500 mb-2">
                <Sparkles className="w-4.5 h-4.5" />
                <h5 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Econometric AI Analysis</h5>
              </div>

              <div className="h-[210px] overflow-y-auto text-xs space-y-2 pr-1 select-text">
                {loadingAiDiagnostic ? (
                  <div className="space-y-2 py-4">
                    <div className="h-3 bg-slate-100 dark:bg-slate-900 rounded animate-pulse w-2/3" />
                    <div className="h-3 bg-slate-100 dark:bg-slate-900 rounded animate-pulse w-full" />
                    <div className="h-3 bg-slate-100 dark:bg-slate-900 rounded animate-pulse w-full" />
                    <div className="h-3 bg-slate-100 dark:bg-slate-900 rounded animate-pulse w-4/5" />
                  </div>
                ) : aiDiagnostic ? (
                  <div className="prose prose-slate dark:prose-invert prose-xs leading-relaxed text-slate-600 dark:text-slate-300">
                    {aiDiagnostic.split('\n').map((line, idx) => (
                      <p key={idx} className="mb-2 leading-relaxed">
                        {line.startsWith('-') || line.startsWith('*') ? (
                          <span className="inline-block pl-2">{line}</span>
                        ) : line}
                      </p>
                    ))}
                  </div>
                ) : (
                  <div className="text-slate-500 dark:text-slate-400 leading-relaxed text-xs">
                    <p className="mb-2">Click **Trigger Econometric AI** to execute deep server-side model auditing. Below is the default statistical projection breakdown:</p>
                    <div className="space-y-2 mt-3 p-2 bg-slate-50 dark:bg-slate-900 rounded-lg border border-slate-100 dark:border-slate-800">
                      <p>
                        • **Trend Velocity**: The variable is traveling at **{analyticsResult.slope.toFixed(4)} units** per step.
                      </p>
                      <p>
                        • **Confidence Corridor**: MAPE error suggests high fitting with average deviation of **{analyticsResult.mape.toFixed(2)}%**.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </GlassCard>
          </div>
        </div>
      ) : (
        <GlassCard id="no-regression-fit" className="text-center py-6">
          <p className="text-xs text-slate-400">Unable to establish OLS fit. Verify data types or selected columns.</p>
        </GlassCard>
      )}
    </div>
  );
};

export default AiPredictiveForecaster;
