import React, { useState, useRef, useEffect } from 'react';
import { DatasetSummary } from '../types';
import GlassCard from './GlassCard';
import { Send, Sparkles, MessageCircle, ArrowRight, User, Trash2, Check, Copy } from 'lucide-react';

interface AiChatbotProps {
  summary: DatasetSummary;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: Date;
}

export const AiChatbot: React.FC<AiChatbotProps> = ({ summary }) => {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    // Welcome message based on columns
    return [
      {
        id: 'welcome',
        sender: 'assistant',
        text: `Hello! I am your **Interactive AI Query Assistant**. I have analyzed the schema of **${summary.fileName}** with **${summary.rowCount} rows** and **${summary.columnCount} columns**. 

How can I help you analyze your data today? You can ask me custom questions or select one of the quick scenarios below.`,
        timestamp: new Date()
      }
    ];
  });
  const [inputValue, setInputValue] = useState('');
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const quickPrompts = [
    { label: '📊 SWOT Analysis', text: 'Provide a comprehensive SWOT analysis of this dataset from a business intelligence perspective.' },
    { label: '🔍 Column Dependencies', text: 'Which columns have the strongest statistical dependencies and what do they imply?' },
    { label: '⚠️ Data Anomalies', text: 'Summarize potential anomalies, outliers, or missing data risks in this dataset.' },
    { label: '📈 Business Value', text: 'What is the absolute highest-value business insight we can extract from this row structure?' }
  ];

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || loading) return;

    const userMsg: ChatMessage = {
      id: Math.random().toString(36).substring(7),
      sender: 'user',
      text: textToSend,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setLoading(true);

    try {
      // Prepare 5 sample rows for model context
      const sample = summary.sampleRows.slice(0, 5);
      
      const response = await fetch('/api/eda/query', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          fileName: summary.fileName,
          columns: summary.columns.map(c => ({
            name: c.name,
            type: c.type,
            uniqueCount: c.uniqueCount,
            missingCount: c.missingCount
          })),
          sampleData: sample,
          rowCount: summary.rowCount,
          userQuestion: textToSend
        })
      });

      const data = await response.json();
      
      const assistantMsg: ChatMessage = {
        id: Math.random().toString(36).substring(7),
        sender: 'assistant',
        text: data.answer || "I'm sorry, I couldn't process that request.",
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (error) {
      console.error('Error querying chat endpoint:', error);
      const errorMsg: ChatMessage = {
        id: Math.random().toString(36).substring(7),
        sender: 'assistant',
        text: `⚠️ **Connection Error**: Unable to contact the AI server. Please verify your internet connection and ensure your API key is configured.`,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleCopyText = (text: string, msgId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(msgId);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const clearChat = () => {
    if (window.confirm('Are you sure you want to clear your conversation history?')) {
      setMessages([
        {
          id: 'welcome',
          sender: 'assistant',
          text: `Chat history cleared. I am ready for new queries regarding **${summary.fileName}**!`,
          timestamp: new Date()
        }
      ]);
    }
  };

  // Basic markdown parser for formatting bold text, lists, and line breaks in chats
  const renderMessageText = (text: string) => {
    return text.split('\n').map((line, index) => {
      // Bold text parser **text**
      let formatted = line;
      const boldRegex = /\*\*(.*?)\*\*/g;
      
      // Basic translation to list items
      const isListItem = line.trim().startsWith('- ');
      const cleanLine = isListItem ? line.trim().substring(2) : line;

      // Match bold parts
      const parts = [];
      let lastIdx = 0;
      let match;
      
      while ((match = boldRegex.exec(cleanLine)) !== null) {
        if (match.index > lastIdx) {
          parts.push(cleanLine.substring(lastIdx, match.index));
        }
        parts.push(<strong key={match.index} className="font-bold text-slate-900 dark:text-emerald-300">{match[1]}</strong>);
        lastIdx = boldRegex.lastIndex;
      }
      
      if (lastIdx < cleanLine.length) {
        parts.push(cleanLine.substring(lastIdx));
      }

      const content = parts.length > 0 ? parts : cleanLine;

      if (isListItem) {
        return (
          <li key={index} className="ml-4 list-disc text-sm text-slate-700 dark:text-slate-300 py-0.5">
            {content}
          </li>
        );
      }

      return (
        <p key={index} className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed mb-1.5">
          {content}
        </p>
      );
    });
  };

  return (
    <div id="ai-chatbot-root" className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      {/* Sidebar with quick start info */}
      <div className="lg:col-span-1 space-y-4">
        <GlassCard id="chatbot-stats-sidebar" className="border-pink-500/10 h-full flex flex-col justify-between p-4">
          <div className="space-y-4">
            <div className="flex items-center space-x-2 text-pink-500">
              <MessageCircle className="w-5 h-5" />
              <h4 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">AI Sandbox</h4>
            </div>
            
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Ask deep conceptual questions about structural columns, quality vectors, or strategic possibilities. The model is context-aware of your uploaded table structure.
            </p>

            <div className="p-3 bg-slate-50 dark:bg-slate-900/60 rounded-xl border border-slate-100 dark:border-slate-800 space-y-2">
              <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-600 dark:text-emerald-400 block">
                Analysis Context
              </span>
              <div className="grid grid-cols-2 gap-2 text-center">
                <div className="bg-white dark:bg-slate-950 p-2 rounded-lg border border-slate-100 dark:border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Rows</span>
                  <span className="font-mono text-xs font-bold text-slate-800 dark:text-white">{summary.rowCount.toLocaleString()}</span>
                </div>
                <div className="bg-white dark:bg-slate-950 p-2 rounded-lg border border-slate-100 dark:border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Columns</span>
                  <span className="font-mono text-xs font-bold text-slate-800 dark:text-white">{summary.columnCount}</span>
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={clearChat}
            className="w-full mt-4 py-2 bg-slate-100 dark:bg-slate-900 hover:bg-red-500/10 hover:text-red-500 dark:hover:bg-red-500/20 text-slate-600 dark:text-slate-400 text-xs font-bold rounded-xl flex items-center justify-center space-x-1.5 transition duration-150 cursor-pointer"
          >
            <Trash2 className="w-4 h-4" />
            <span>Clear Conversation</span>
          </button>
        </GlassCard>
      </div>

      {/* Main chat layout */}
      <div className="lg:col-span-3 flex flex-col h-[520px] bg-white/40 dark:bg-slate-950/40 backdrop-blur-md rounded-2xl border border-slate-200/50 dark:border-slate-800/50 overflow-hidden shadow-xl">
        {/* Messages list Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${
                msg.sender === 'user' ? 'flex-row-reverse' : 'flex-row'
              }`}
            >
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border shadow-sm ${
                  msg.sender === 'user'
                    ? 'bg-gradient-to-br from-pink-500 to-pink-600 border-pink-500 text-white'
                    : 'bg-gradient-to-br from-emerald-500 to-emerald-600 border-emerald-500 text-white'
                }`}
              >
                {msg.sender === 'user' ? (
                  <User className="w-4 h-4" />
                ) : (
                  <Sparkles className="w-4 h-4" />
                )}
              </div>

              <div className="space-y-1 max-w-[82%]">
                <div
                  className={`p-3.5 rounded-2xl text-slate-800 dark:text-slate-100 relative group transition-all duration-150 ${
                    msg.sender === 'user'
                      ? 'bg-pink-500/10 border border-pink-500/20 rounded-tr-none'
                      : 'bg-slate-100/80 dark:bg-slate-900/80 border border-slate-200/30 dark:border-slate-800/30 rounded-tl-none'
                  }`}
                >
                  <div className="pr-6">{renderMessageText(msg.text)}</div>
                  
                  {/* Quick Copy button */}
                  <button
                    onClick={() => handleCopyText(msg.text, msg.id)}
                    className="absolute right-2.5 top-2.5 opacity-0 group-hover:opacity-100 p-1 hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 rounded transition duration-150 cursor-pointer"
                    title="Copy response"
                  >
                    {copiedId === msg.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-500" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
                <span className="text-[9px] text-slate-400 block px-1">
                  {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
          ))}

          {/* Typing Indicator */}
          {loading && (
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500 to-emerald-600 border border-emerald-500 text-white flex items-center justify-center">
                <Sparkles className="w-4 h-4" />
              </div>
              <div className="p-3.5 bg-slate-100 dark:bg-slate-900/80 border border-slate-200/30 dark:border-slate-800/30 rounded-2xl rounded-tl-none flex items-center space-x-2">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 rounded-full bg-slate-400 dark:bg-emerald-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 rounded-full bg-slate-400 dark:bg-emerald-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-2 h-2 rounded-full bg-slate-400 dark:bg-emerald-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
                <span className="text-xs text-slate-400 italic">Gemini is computing answer...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Prompts Panel */}
        {messages.length === 1 && !loading && (
          <div className="px-4 py-2 border-t border-slate-100 dark:border-slate-900 bg-slate-50/50 dark:bg-slate-950/50">
            <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400 block mb-1.5">
              Suggested Questions
            </span>
            <div className="flex flex-wrap gap-2">
              {quickPrompts.map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendMessage(p.text)}
                  className="px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-pink-500/30 dark:hover:border-pink-500/30 text-xs font-semibold text-slate-700 dark:text-slate-300 rounded-lg hover:bg-pink-500/5 dark:hover:bg-pink-500/10 transition cursor-pointer flex items-center space-x-1"
                >
                  <span>{p.label}</span>
                  <ArrowRight className="w-3 h-3 text-slate-400" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input Form Box */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage(inputValue);
          }}
          className="p-3 border-t border-slate-200/50 dark:border-slate-800/50 bg-slate-50 dark:bg-slate-950 flex gap-2 items-center"
        >
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder={`Ask a question about ${summary.fileName}...`}
            disabled={loading}
            className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm text-slate-800 dark:text-white focus:outline-none focus:ring-1 focus:ring-pink-500 focus:border-pink-500 disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={!inputValue.trim() || loading}
            className="p-2.5 bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white rounded-xl disabled:opacity-40 transition cursor-pointer shadow-md flex items-center justify-center shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};

export default AiChatbot;
