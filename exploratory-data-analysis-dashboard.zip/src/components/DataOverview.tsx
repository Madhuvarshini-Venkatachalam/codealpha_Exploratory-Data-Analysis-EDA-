import React, { useState } from 'react';
import { ColumnMetadata, DatasetSummary, FilterCondition } from '../types';
import GlassCard from './GlassCard';
import { Database, FileText, FileCode, CheckCircle2, AlertTriangle, Filter, Plus, Trash2, Search, ArrowRight, Table } from 'lucide-react';

interface DataOverviewProps {
  summary: DatasetSummary;
  filteredRows: Record<string, any>[];
  filters: FilterCondition[];
  onAddFilter: (condition: FilterCondition) => void;
  onRemoveFilter: (index: number) => void;
  onClearFilters: () => void;
}

export const DataOverview: React.FC<DataOverviewProps> = ({
  summary,
  filteredRows,
  filters,
  onAddFilter,
  onRemoveFilter,
  onClearFilters
}) => {
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 10;
  
  // Filter creator state
  const [filterColumn, setFilterColumn] = useState(summary.columns[0]?.name || '');
  const [filterOperator, setFilterOperator] = useState<'equals' | 'contains' | 'greater_than' | 'less_than' | 'not_empty'>('contains');
  const [filterValue, setFilterValue] = useState('');

  // Number of numeric, categorical, datetime, boolean columns
  const typeCounts = summary.columns.reduce(
    (acc, col) => {
      acc[col.type] = (acc[col.type] || 0) + 1;
      return acc;
    },
    { numeric: 0, categorical: 0, datetime: 0, boolean: 0 }
  );

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleAddFilter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!filterColumn) return;
    if (filterOperator !== 'not_empty' && !filterValue.trim()) return;

    onAddFilter({
      columnName: filterColumn,
      operator: filterOperator,
      value: filterValue
    });
    setFilterValue('');
    setCurrentPage(1);
  };

  // Pagination for grid preview
  const totalPages = Math.ceil(filteredRows.length / rowsPerPage);
  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = filteredRows.slice(indexOfFirstRow, indexOfLastRow);

  return (
    <div id="data-overview-container" className="space-y-6">
      {/* KPI Cards Grid */}
      <div id="kpi-grid" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <GlassCard id="kpi-rows" glowColor="pink" className="flex items-center space-x-4">
          <div className="p-3 bg-pink-100 dark:bg-pink-900/30 text-pink-600 dark:text-pink-400 rounded-xl">
            <Database className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold">Row Count</p>
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
              {filteredRows.length.toLocaleString()}
              {filteredRows.length !== summary.rowCount && (
                <span className="text-xs text-slate-400 font-normal ml-1">
                  (of {summary.rowCount.toLocaleString()})
                </span>
              )}
            </h3>
          </div>
        </GlassCard>

        <GlassCard id="kpi-cols" glowColor="green" className="flex items-center space-x-4">
          <div className="p-3 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-xl">
            <FileCode className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold">Column Count</p>
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
              {summary.columnCount}
            </h3>
          </div>
        </GlassCard>

        <GlassCard id="kpi-duplicates" glowColor={summary.duplicateCount > 0 ? 'pink' : 'none'} className="flex items-center space-x-4">
          <div className={`p-3 rounded-xl ${
            summary.duplicateCount > 0 
              ? 'bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400' 
              : 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400'
          }`}>
            {summary.duplicateCount > 0 ? <AlertTriangle className="w-6 h-6" /> : <CheckCircle2 className="w-6 h-6" />}
          </div>
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold">Duplicates</p>
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
              {summary.duplicateCount.toLocaleString()}
            </h3>
          </div>
        </GlassCard>

        <GlassCard id="kpi-memory" className="flex items-center space-x-4">
          <div className="p-3 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-xl">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold">Memory Footprint</p>
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
              {formatBytes(summary.totalMemoryBytes)}
            </h3>
          </div>
        </GlassCard>
      </div>

      {/* Interactive Slicer/Filters Panel */}
      <GlassCard id="filters-panel" className="border-pink-500/10">
        <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4 mb-4">
          <div className="flex items-center space-x-2 text-pink-500">
            <Filter className="w-5 h-5" />
            <h4 className="font-semibold text-slate-950 dark:text-white">Power Slicer (Dataset Filters)</h4>
          </div>
          <span className="text-xs text-slate-500 dark:text-slate-400 mt-1 md:mt-0">
            Slicing dynamic rows re-evaluates all downstream calculations.
          </span>
        </div>

        {/* Filter Builder Form */}
        <form onSubmit={handleAddFilter} className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
          <div className="space-y-1">
            <label className="text-xs text-slate-500 dark:text-slate-400 font-medium">Select Column</label>
            <select
              value={filterColumn}
              onChange={(e) => setFilterColumn(e.target.value)}
              className="w-full text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white outline-none focus:border-pink-500"
            >
              {summary.columns.map(c => (
                <option key={c.name} value={c.name}>{c.name} ({c.type})</option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-xs text-slate-500 dark:text-slate-400 font-medium">Operator</label>
            <select
              value={filterOperator}
              onChange={(e: any) => setFilterOperator(e.target.value)}
              className="w-full text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white outline-none focus:border-pink-500"
            >
              <option value="contains">Contains</option>
              <option value="equals">Equals</option>
              <option value="greater_than">Greater than (&gt;)</option>
              <option value="less_than">Less than (&lt;)</option>
              <option value="not_empty">Is Not Empty</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-xs text-slate-500 dark:text-slate-400 font-medium">Filter Value</label>
            <input
              type="text"
              placeholder={filterOperator === 'not_empty' ? 'N/A' : 'Type comparison value...'}
              disabled={filterOperator === 'not_empty'}
              value={filterValue}
              onChange={(e) => setFilterValue(e.target.value)}
              className="w-full text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white outline-none focus:border-pink-500 placeholder:text-slate-400"
            />
          </div>

          <button
            type="submit"
            className="bg-pink-500 hover:bg-pink-600 text-white text-sm font-medium h-[38px] rounded-xl px-4 flex items-center justify-center space-x-1.5 shadow-sm shadow-pink-500/20 cursor-pointer active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Apply Slicer</span>
          </button>
        </form>

        {/* Active Slicers List */}
        {filters.length > 0 && (
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider">Active Row Slicers</span>
              <button
                type="button"
                onClick={onClearFilters}
                className="text-xs text-pink-500 hover:text-pink-600 font-semibold flex items-center space-x-1 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear All Slicers</span>
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {filters.map((filter, index) => (
                <div
                  key={index}
                  className="inline-flex items-center space-x-1.5 px-3 py-1 bg-pink-50 dark:bg-pink-950/20 text-pink-600 dark:text-pink-400 rounded-full text-xs font-medium border border-pink-100 dark:border-pink-900/30"
                >
                  <span className="opacity-70">{filter.columnName}</span>
                  <span className="font-bold text-pink-700 dark:text-pink-300">
                    {filter.operator === 'contains' && 'contains'}
                    {filter.operator === 'equals' && '='}
                    {filter.operator === 'greater_than' && '>'}
                    {filter.operator === 'less_than' && '<'}
                    {filter.operator === 'not_empty' && 'not empty'}
                  </span>
                  {filter.operator !== 'not_empty' && <span>"{filter.value}"</span>}
                  <button
                    type="button"
                    onClick={() => onRemoveFilter(index)}
                    className="hover:bg-pink-100 dark:hover:bg-pink-900/30 rounded-full p-0.5 ml-1 transition"
                  >
                    <Trash2 className="w-3 h-3 text-pink-500" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </GlassCard>

      {/* Columns Metadata Table */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <GlassCard id="columns-structure" className="lg:col-span-2">
          <h4 className="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center space-x-2">
            <Table className="w-5 h-5 text-emerald-500" />
            <span>Dataset Schema & Column Audit</span>
          </h4>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider">
                  <th className="py-2.5 px-2">Column Name</th>
                  <th className="py-2.5 px-2">Inferred Type</th>
                  <th className="py-2.5 px-2 text-right">Missing Records</th>
                  <th className="py-2.5 px-2 text-right">Cardinality (Unique)</th>
                  <th className="py-2.5 px-2">Sample Values</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                {summary.columns.map((c) => (
                  <tr key={c.name} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20">
                    <td className="py-2 px-2 font-mono font-medium text-pink-600 dark:text-pink-400">{c.name}</td>
                    <td className="py-2 px-2">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider border ${
                        c.type === 'numeric' 
                          ? 'bg-blue-50 dark:bg-blue-950/20 text-blue-600 dark:text-blue-400 border-blue-100 dark:border-blue-900/30'
                          : c.type === 'datetime'
                          ? 'bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/30'
                          : c.type === 'boolean'
                          ? 'bg-purple-50 dark:bg-purple-950/20 text-purple-600 dark:text-purple-400 border-purple-100 dark:border-purple-900/30'
                          : 'bg-orange-50 dark:bg-orange-950/20 text-orange-600 dark:text-orange-400 border-orange-100 dark:border-orange-900/30'
                      }`}>
                        {c.type}
                      </span>
                    </td>
                    <td className="py-2 px-2 text-right">
                      {c.missingCount > 0 ? (
                        <span className="text-amber-600 dark:text-amber-400 font-semibold">
                          {c.missingCount.toLocaleString()} ({c.missingPercentage}%)
                        </span>
                      ) : (
                        <span className="text-slate-400 font-normal">0%</span>
                      )}
                    </td>
                    <td className="py-2 px-2 text-right font-medium">
                      {c.uniqueCount.toLocaleString()}
                    </td>
                    <td className="py-2 px-2 max-w-[220px] truncate font-mono text-slate-400 dark:text-slate-500">
                      {c.uniqueValues.join(', ')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </GlassCard>

        {/* Data Type Composition Ring */}
        <GlassCard id="schema-composition">
          <h4 className="text-lg font-bold text-slate-900 dark:text-white mb-4">Column Type Distribution</h4>
          <div className="space-y-4">
            <div className="flex justify-between items-center text-sm">
              <span className="flex items-center space-x-2 text-slate-600 dark:text-slate-300">
                <span className="w-3 h-3 bg-blue-500 rounded-full" />
                <span>Numeric</span>
              </span>
              <span className="font-bold">{typeCounts.numeric} columns</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="flex items-center space-x-2 text-slate-600 dark:text-slate-300">
                <span className="w-3 h-3 bg-orange-500 rounded-full" />
                <span>Categorical</span>
              </span>
              <span className="font-bold">{typeCounts.categorical} columns</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="flex items-center space-x-2 text-slate-600 dark:text-slate-300">
                <span className="w-3 h-3 bg-emerald-500 rounded-full" />
                <span>Datetime</span>
              </span>
              <span className="font-bold">{typeCounts.datetime} columns</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="flex items-center space-x-2 text-slate-600 dark:text-slate-300">
                <span className="w-3 h-3 bg-purple-500 rounded-full" />
                <span>Boolean</span>
              </span>
              <span className="font-bold">{typeCounts.boolean} columns</span>
            </div>
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
              <p className="leading-relaxed">
                We've performed an automated scan of all items. We classified features that are standard digits, clean floating points, percentages, or money indicators as <strong className="text-pink-500">Numeric</strong>.
              </p>
            </div>
          </div>
        </GlassCard>
      </div>

      {/* Dynamic Data Preview Grid */}
      <GlassCard id="data-preview" glowColor="none">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4">
          <div>
            <h4 className="text-lg font-bold text-slate-900 dark:text-white flex items-center space-x-2">
              <Search className="w-5 h-5 text-pink-500" />
              <span>Interactive Data Preview</span>
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Showing active records {indexOfFirstRow + 1} - {Math.min(indexOfLastRow, filteredRows.length)} of {filteredRows.length.toLocaleString()} records.
            </p>
          </div>
          <div className="mt-2 sm:mt-0 flex items-center space-x-2 text-xs">
            <span className="text-slate-500">Records per page:</span>
            <strong className="px-2 py-1 bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-lg">10</strong>
          </div>
        </div>

        {/* Paginated Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/30 text-slate-600 dark:text-slate-300 font-semibold">
                <th className="py-2.5 px-3 text-center text-slate-400">#</th>
                {summary.columns.map(c => (
                  <th key={c.name} className="py-2.5 px-3 font-mono text-pink-600 dark:text-pink-400 font-semibold border-r border-slate-100 dark:border-slate-800">
                    {c.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-800 dark:text-slate-200">
              {currentRows.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-850/10">
                  <td className="py-2 px-3 text-center text-slate-400 bg-slate-50/20 dark:bg-slate-900/10 border-r border-slate-100 dark:border-slate-800">
                    {indexOfFirstRow + idx + 1}
                  </td>
                  {summary.columns.map(c => (
                    <td key={c.name} className="py-2 px-3 font-mono truncate max-w-[200px] border-r border-slate-100 dark:border-slate-800">
                      {row[c.name] === null || row[c.name] === undefined ? (
                        <span className="text-red-500/80 italic bg-red-50 dark:bg-red-950/10 px-1.5 py-0.5 rounded font-normal">NaN</span>
                      ) : (
                        String(row[c.name])
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination controls */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              disabled={currentPage === 1}
              className="text-xs font-semibold px-3 py-1.5 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-50 disabled:hover:bg-slate-50 dark:disabled:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl transition cursor-pointer"
            >
              Previous
            </button>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Page <strong>{currentPage}</strong> of <strong>{totalPages}</strong>
            </span>
            <button
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
              disabled={currentPage === totalPages}
              className="text-xs font-semibold px-3 py-1.5 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-50 disabled:hover:bg-slate-50 dark:disabled:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl transition cursor-pointer"
            >
              Next
            </button>
          </div>
        )}
      </GlassCard>
    </div>
  );
};
export default DataOverview;
