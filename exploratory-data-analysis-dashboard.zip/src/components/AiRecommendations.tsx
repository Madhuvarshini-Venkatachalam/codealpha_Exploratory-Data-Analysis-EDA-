import React, { useState } from 'react';
import { BusinessQuestion, DatasetSummary } from '../types';
import GlassCard from './GlassCard';
import AiChatbot from './AiChatbot';
import AiPredictiveForecaster from './AiPredictiveForecaster';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, MessageSquare, HelpCircle, Target, Lightbulb, TrendingUp, Cpu } from 'lucide-react';

interface AiRecommendationsProps {
  summary: DatasetSummary;
  questions: BusinessQuestion[];
  conclusions: string[];
  recommendations: string[];
  loading: boolean;
  onRefresh: () => void;
}

export const AiRecommendations: React.FC<AiRecommendationsProps> = ({
  summary,
  questions,
  conclusions,
  recommendations,
  loading,
  onRefresh
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'strategic' | 'chatbot' | 'predictive'>('strategic');

  return (
    <div id="ai-recs-container" className="space-y-6">
      {/* Top Banner */}
      <GlassCard id="recs-banner" glowColor="pink" className="bg-gradient-to-r from-pink-500/10 via-transparent to-emerald-500/10 border-pink-500/20">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2 text-pink-500">
              <Cpu className="w-5 h-5 text-pink-500" />
              <h3 className="text-lg font-bold text-slate-900 dark:text-white uppercase tracking-wider">AI Business intelligence Hub</h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Harness predictive analytics and generative insights directly contextualized by your dataset.
            </p>
          </div>
          {activeSubTab === 'strategic' && (
            <button
              onClick={onRefresh}
              disabled={loading}
              className="px-4 py-2 bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white text-xs font-bold rounded-xl shadow-lg shadow-pink-500/20 flex items-center space-x-1.5 cursor-pointer disabled:opacity-50 self-start md:self-auto transition active:scale-95"
            >
              <RefreshCwIcon className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              <span>{loading ? 'Consulting Brain...' : 'Regenerate Advisor AI'}</span>
            </button>
          )}
        </div>
      </GlassCard>

      {/* Sub-Tabs Navigation */}
      <div className="flex border-b border-slate-200/50 dark:border-slate-800/50 pb-px space-x-4 md:space-x-8 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setActiveSubTab('strategic')}
          className={`pb-3 text-xs uppercase font-bold tracking-widest transition-all duration-200 border-b-2 cursor-pointer whitespace-nowrap ${
            activeSubTab === 'strategic'
              ? 'text-pink-500 border-pink-500 font-extrabold'
              : 'text-slate-400 border-transparent hover:text-slate-600 dark:hover:text-slate-200'
          }`}
        >
          1. Strategic Advisor
        </button>
        <button
          onClick={() => setActiveSubTab('chatbot')}
          className={`pb-3 text-xs uppercase font-bold tracking-widest transition-all duration-200 border-b-2 cursor-pointer whitespace-nowrap ${
            activeSubTab === 'chatbot'
              ? 'text-pink-500 border-pink-500 font-extrabold'
              : 'text-slate-400 border-transparent hover:text-slate-600 dark:hover:text-slate-200'
          }`}
        >
          2. Interactive AI Assistant
        </button>
        <button
          onClick={() => setActiveSubTab('predictive')}
          className={`pb-3 text-xs uppercase font-bold tracking-widest transition-all duration-200 border-b-2 cursor-pointer whitespace-nowrap ${
            activeSubTab === 'predictive'
              ? 'text-pink-500 border-pink-500 font-extrabold'
              : 'text-slate-400 border-transparent hover:text-slate-600 dark:hover:text-slate-200'
          }`}
        >
          3. Predictive Forecasting
        </button>
      </div>

      {/* Active Sub-tab View */}
      <AnimatePresence mode="wait">
        {activeSubTab === 'strategic' && (
          <motion.div
            key="strategic-view"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="space-y-6"
          >
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <GlassCard id="shimmer-1" className="space-y-3">
                  <div className="h-4 bg-slate-100 dark:bg-slate-800 rounded animate-pulse w-1/3" />
                  <div className="h-16 bg-slate-100 dark:bg-slate-800 rounded animate-pulse w-full" />
                  <div className="h-16 bg-slate-100 dark:bg-slate-800 rounded animate-pulse w-full" />
                </GlassCard>
                <GlassCard id="shimmer-2" className="space-y-3">
                  <div className="h-4 bg-slate-100 dark:bg-slate-800 rounded animate-pulse w-1/3" />
                  <div className="h-16 bg-slate-100 dark:bg-slate-800 rounded animate-pulse w-full" />
                  <div className="h-16 bg-slate-100 dark:bg-slate-800 rounded animate-pulse w-full" />
                </GlassCard>
              </div>
            ) : (
              <>
                {/* Executive Conclusions & Strategic Recommendations */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Conclusions */}
                  <GlassCard id="conclusions-card" glowColor="pink" className="border-pink-500/10">
                    <h4 className="text-base font-bold text-slate-900 dark:text-white mb-4 flex items-center space-x-2">
                      <Target className="w-5 h-5 text-pink-500 shrink-0" />
                      <span>Executive Findings & Conclusions</span>
                    </h4>
                    <div className="space-y-3">
                      {conclusions.length > 0 ? (
                        conclusions.map((point, idx) => (
                          <div key={idx} className="flex items-start space-x-3 text-sm">
                            <span className="flex items-center justify-center w-5 h-5 rounded-full bg-pink-100 dark:bg-pink-950/40 text-pink-600 dark:text-pink-400 text-xs font-bold shrink-0 mt-0.5">
                              {idx + 1}
                            </span>
                            <p className="text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
                              {point}
                            </p>
                          </div>
                        ))
                      ) : (
                        <p className="text-xs text-slate-400 italic">No executive findings recorded. Trigger recommendations above.</p>
                      )}
                    </div>
                  </GlassCard>

                  {/* Strategic Recommendations */}
                  <GlassCard id="recommendations-card" glowColor="green" className="border-emerald-500/10">
                    <h4 className="text-base font-bold text-slate-900 dark:text-white mb-4 flex items-center space-x-2">
                      <Lightbulb className="w-5 h-5 text-emerald-500 shrink-0" />
                      <span>Actionable Business Recommendations</span>
                    </h4>
                    <div className="space-y-3">
                      {recommendations.length > 0 ? (
                        recommendations.map((point, idx) => (
                          <div key={idx} className="flex items-start space-x-3 text-sm">
                            <span className="flex items-center justify-center w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 text-xs font-bold shrink-0 mt-0.5">
                              {idx + 1}
                            </span>
                            <p className="text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
                              {point}
                            </p>
                          </div>
                        ))
                      ) : (
                        <p className="text-xs text-slate-400 italic">No business recommendations logged. Trigger analysis above.</p>
                      )}
                    </div>
                  </GlassCard>
                </div>

                {/* Business Questions tailored */}
                <GlassCard id="business-questions-card">
                  <h4 className="text-base font-bold text-slate-900 dark:text-white mb-4 flex items-center space-x-2">
                    <MessageSquare className="w-5 h-5 text-pink-500" />
                    <span>Targeted Business Inquiry Scenarios</span>
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {questions.length > 0 ? (
                      questions.map((q, idx) => (
                        <div
                          key={idx}
                          className="p-4 bg-slate-50 dark:bg-slate-900/40 rounded-xl border border-slate-100 dark:border-slate-800 hover:border-pink-500/20 hover:bg-slate-100/50 dark:hover:bg-slate-900/60 transition-all duration-200 flex space-x-3.5"
                        >
                          <div className="p-2.5 bg-pink-100 dark:bg-pink-950/30 text-pink-600 dark:text-pink-400 h-10 rounded-lg shrink-0 flex items-center justify-center">
                            <HelpCircle className="w-5 h-5" />
                          </div>
                          <div className="space-y-1">
                            <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-600 dark:text-emerald-400 block font-sans">
                              {q.category}
                            </span>
                            <h5 className="font-bold text-xs text-slate-900 dark:text-white leading-normal">
                              {q.question}
                            </h5>
                            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                              {q.description}
                            </p>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-xs text-slate-400 italic md:col-span-2">No tailored questions created. Upload a valid dataset to trigger.</p>
                    )}
                  </div>
                </GlassCard>
              </>
            )}
          </motion.div>
        )}

        {activeSubTab === 'chatbot' && (
          <motion.div
            key="chatbot-view"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            <AiChatbot summary={summary} />
          </motion.div>
        )}

        {activeSubTab === 'predictive' && (
          <motion.div
            key="predictive-view"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            <AiPredictiveForecaster summary={summary} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

// Reusable spinner icon inside file
const RefreshCwIcon = ({ className = '' }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
    <path d="M3 3v5h5" />
    <path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16" />
    <path d="M16 16h5v5" />
  </svg>
);

export default AiRecommendations;
