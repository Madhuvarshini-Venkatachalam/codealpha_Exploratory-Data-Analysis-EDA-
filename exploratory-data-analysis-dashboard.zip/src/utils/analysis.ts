import { ColumnMetadata, ColumnType, DatasetSummary, CorrelationCell } from '../types';

/**
 * Calculates a Pearson correlation coefficient between two numeric arrays
 */
function calculatePearsonCorrelation(x: number[], y: number[]): number {
  const n = x.length;
  if (n === 0 || n !== y.length) return 0;

  let sumX = 0, sumY = 0, sumXY = 0;
  let sumX2 = 0, sumY2 = 0;

  for (let i = 0; i < n; i++) {
    sumX += x[i];
    sumY += y[i];
    sumXY += x[i] * y[i];
    sumX2 += x[i] * x[i];
    sumY2 += y[i] * y[i];
  }

  const num = n * sumXY - sumX * sumY;
  const den = Math.sqrt((n * sumX2 - sumX * sumX) * (n * sumY2 - sumY * sumY));

  if (den === 0) return 0;
  return parseFloat((num / den).toFixed(3));
}

/**
 * Helper to estimate memory usage of a value in bytes
 */
function getMemoryUsageOfValue(val: any): number {
  if (val === null || val === undefined) return 0;
  switch (typeof val) {
    case 'number': return 8;
    case 'boolean': return 4;
    case 'string': return val.length * 2;
    case 'object':
      if (Array.isArray(val)) {
        return val.reduce((acc, v) => acc + getMemoryUsageOfValue(v), 0);
      }
      return Object.keys(val).reduce((acc, k) => acc + getMemoryUsageOfValue(k) + getMemoryUsageOfValue(val[k]), 0);
    default: return 8;
  }
}

/**
 * Parses and runs full descriptive analysis on dataset rows
 */
export function analyzeDataset(
  fileName: string,
  fileSize: number,
  allRows: Record<string, any>[]
): DatasetSummary {
  const rowCount = allRows.length;
  if (rowCount === 0) {
    return {
      fileName,
      fileSize,
      rowCount: 0,
      columnCount: 0,
      duplicateCount: 0,
      totalMemoryBytes: 0,
      columns: [],
      sampleRows: [],
      allRows: [],
      correlationMatrix: []
    };
  }

  const columnNames = Object.keys(allRows[0]);
  const columnCount = columnNames.length;

  // Let's determine duplicate rows
  const stringifiedRows = allRows.map(row => JSON.stringify(row));
  const uniqueRowsSet = new Set(stringifiedRows);
  const duplicateCount = rowCount - uniqueRowsSet.size;

  // Track memory usage
  let totalMemoryBytes = fileSize || 0;
  if (totalMemoryBytes === 0) {
    totalMemoryBytes = allRows.reduce((acc, row) => acc + getMemoryUsageOfValue(row), 0);
  }

  // Pre-analyze columns to detect data types
  const columns: ColumnMetadata[] = columnNames.map(colName => {
    let missingCount = 0;
    const values: any[] = [];
    let numericCount = 0;
    let dateCount = 0;
    let booleanCount = 0;
    let colMemoryUsage = 0;

    for (let r = 0; r < rowCount; r++) {
      const val = allRows[r][colName];
      colMemoryUsage += getMemoryUsageOfValue(val);

      if (val === null || val === undefined || val === '' || String(val).trim().toLowerCase() === 'null' || String(val).trim().toLowerCase() === 'na' || String(val).trim().toLowerCase() === 'nan') {
        missingCount++;
        continue;
      }

      values.push(val);

      // Check if boolean
      const strVal = String(val).trim().toLowerCase();
      if (strVal === 'true' || strVal === 'false' || val === true || val === false) {
        booleanCount++;
      }

      // Check if numeric (stripping currency, commas for dynamic cleaning)
      const cleanNumStr = strVal.replace(/[$,%]/g, '');
      const numVal = Number(cleanNumStr);
      if (!isNaN(numVal) && cleanNumStr !== '') {
        numericCount++;
      }

      // Check if valid date (avoid small integers)
      const dateVal = Date.parse(strVal);
      if (!isNaN(dateVal) && isNaN(Number(strVal)) && strVal.length >= 6) {
        dateCount++;
      }
    }

    // Determine type
    let type: ColumnType = 'categorical';
    const nonMissingCount = values.length;
    if (nonMissingCount > 0) {
      if (numericCount / nonMissingCount > 0.7) {
        type = 'numeric';
      } else if (dateCount / nonMissingCount > 0.7) {
        type = 'datetime';
      } else if (booleanCount / nonMissingCount > 0.7) {
        type = 'boolean';
      }
    }

    const uniqueValuesSet = new Set(values);
    const uniqueCount = uniqueValuesSet.size;
    const uniqueValuesSample = Array.from(uniqueValuesSet).slice(0, 15).map(String);

    const missingPercentage = parseFloat(((missingCount / rowCount) * 100).toFixed(2));

    const meta: ColumnMetadata = {
      name: colName,
      type,
      missingCount,
      missingPercentage,
      uniqueCount,
      uniqueValues: uniqueValuesSample,
      memoryUsageBytes: colMemoryUsage,
    };

    // Calculate numeric statistics
    if (type === 'numeric') {
      const numValues = values
        .map(v => Number(String(v).replace(/[$,%]/g, '')))
        .filter(v => !isNaN(v))
        .sort((a, b) => a - b);

      if (numValues.length > 0) {
        const sum = numValues.reduce((a, b) => a + b, 0);
        const mean = sum / numValues.length;
        
        // Median
        const mid = Math.floor(numValues.length / 2);
        const median = numValues.length % 2 !== 0 
          ? numValues[mid] 
          : (numValues[mid - 1] + numValues[mid]) / 2;

        const min = numValues[0];
        const max = numValues[numValues.length - 1];

        // Std Dev
        const variance = numValues.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / numValues.length;
        const stdDev = Math.sqrt(variance);

        // Q1, Q3 (Quartiles)
        const getQuartile = (q: number) => {
          const pos = (numValues.length - 1) * q;
          const base = Math.floor(pos);
          const rest = pos - base;
          if (numValues[base + 1] !== undefined) {
            return numValues[base] + rest * (numValues[base + 1] - numValues[base]);
          } else {
            return numValues[base];
          }
        };

        const q1 = getQuartile(0.25);
        const q3 = getQuartile(0.75);
        const iqr = q3 - q1;

        // Outliers detection using IQR rule
        const lowerBound = q1 - 1.5 * iqr;
        const upperBound = q3 + 1.5 * iqr;
        const outliersList = numValues.filter(v => v < lowerBound || v > upperBound);
        const outlierCount = outliersList.length;

        meta.mean = parseFloat(mean.toFixed(4));
        meta.median = parseFloat(median.toFixed(4));
        meta.min = parseFloat(min.toFixed(4));
        meta.max = parseFloat(max.toFixed(4));
        meta.stdDev = parseFloat(stdDev.toFixed(4));
        meta.q1 = parseFloat(q1.toFixed(4));
        meta.q3 = parseFloat(q3.toFixed(4));
        meta.iqr = parseFloat(iqr.toFixed(4));
        meta.outlierCount = outlierCount;
        meta.outliers = outliersList.slice(0, 50); // Sample outliers
      }
    }

    return meta;
  });

  // Calculate Correlation Matrix for numeric columns
  const numericColumns = columns.filter(c => c.type === 'numeric');
  const correlationMatrix: CorrelationCell[] = [];

  for (let i = 0; i < numericColumns.length; i++) {
    for (let j = 0; j < numericColumns.length; j++) {
      const col1 = numericColumns[i].name;
      const col2 = numericColumns[j].name;

      // Extract paired values, skipping any row with missing or NaN values in either column
      const x: number[] = [];
      const y: number[] = [];

      for (let r = 0; r < rowCount; r++) {
        const val1 = Number(String(allRows[r][col1]).replace(/[$,%]/g, ''));
        const val2 = Number(String(allRows[r][col2]).replace(/[$,%]/g, ''));

        if (!isNaN(val1) && !isNaN(val2) && allRows[r][col1] !== null && allRows[r][col2] !== null) {
          x.push(val1);
          y.push(val2);
        }
      }

      if (x.length > 1) {
        const value = calculatePearsonCorrelation(x, y);
        correlationMatrix.push({ col1, col2, value });
      } else {
        correlationMatrix.push({ col1, col2, value: 0 });
      }
    }
  }

  // Get sample of first 100 rows for quick UI preview rendering
  const sampleRows = allRows.slice(0, 100);

  return {
    fileName,
    fileSize,
    rowCount,
    columnCount,
    duplicateCount,
    totalMemoryBytes,
    columns,
    sampleRows,
    allRows,
    correlationMatrix
  };
}

/**
 * Groups and creates distribution data for a single column
 */
export function getDistributionData(
  allRows: Record<string, any>[],
  column: ColumnMetadata,
  maxBins = 10
): { name: string; value: number }[] {
  const colName = column.name;
  
  if (column.type === 'numeric') {
    // Determine bins
    const values = allRows
      .map(r => Number(String(r[colName]).replace(/[$,%]/g, '')))
      .filter(v => !isNaN(v))
      .sort((a, b) => a - b);

    if (values.length === 0) return [];

    const min = values[0];
    const max = values[values.length - 1];
    
    if (min === max) {
      return [{ name: String(min), value: values.length }];
    }

    const binSize = (max - min) / maxBins;
    const bins = Array.from({ length: maxBins }, (_, i) => {
      const start = min + i * binSize;
      const end = start + binSize;
      return {
        start,
        end,
        name: `${start.toFixed(1)} - ${end.toFixed(1)}`,
        value: 0
      };
    });

    for (const v of values) {
      let placed = false;
      for (let i = 0; i < maxBins; i++) {
        const bin = bins[i];
        if (v >= bin.start && v <= bin.end + 0.000001) {
          bin.value++;
          placed = true;
          break;
        }
      }
      if (!placed && v > max) {
        bins[maxBins - 1].value++;
      }
    }

    return bins.map(b => ({ name: b.name, value: b.value }));
  } else {
    // Categorical / Boolean / Date
    const counts: Record<string, number> = {};
    for (const r of allRows) {
      let val = r[colName];
      if (val === null || val === undefined || val === '') {
        val = 'MISSING';
      }
      const strVal = String(val);
      counts[strVal] = (counts[strVal] || 0) + 1;
    }

    return Object.entries(counts)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, maxBins);
  }
}

/**
 * Creates scatter plot points between X and Y columns
 */
export function getRelationshipData(
  allRows: Record<string, any>[],
  xCol: string,
  yCol: string,
  sampleSize = 500
): { x: number; y: number; label?: string }[] {
  const points: { x: number; y: number; label?: string }[] = [];
  
  for (let r = 0; r < allRows.length; r++) {
    const valX = Number(String(allRows[r][xCol]).replace(/[$,%]/g, ''));
    const valY = Number(String(allRows[r][yCol]).replace(/[$,%]/g, ''));
    
    if (!isNaN(valX) && !isNaN(valY) && allRows[r][xCol] !== null && allRows[r][yCol] !== null) {
      // Find a categorical label to show on tooltip
      let label = '';
      const otherKeys = Object.keys(allRows[r]).filter(k => k !== xCol && k !== yCol);
      if (otherKeys.length > 0) {
        label = String(allRows[r][otherKeys[0]] || '');
      }
      points.push({ x: valX, y: valY, label });
    }
  }

  // Downsample if too large for fluid rendering
  if (points.length > sampleSize) {
    const step = Math.floor(points.length / sampleSize);
    return points.filter((_, idx) => idx % step === 0).slice(0, sampleSize);
  }

  return points;
}

/**
 * Groups a numeric metric by a categorical category
 */
export function getCategoricalAnalysis(
  allRows: Record<string, any>[],
  catCol: string,
  numCol: string
): { name: string; sum: number; average: number; count: number }[] {
  const groups: Record<string, { sum: number; count: number }> = {};

  for (const r of allRows) {
    let catVal = r[catCol];
    if (catVal === null || catVal === undefined || catVal === '') {
      catVal = 'MISSING';
    }
    const category = String(catVal);
    const numVal = Number(String(r[numCol]).replace(/[$,%]/g, ''));

    if (!isNaN(numVal) && r[numCol] !== null) {
      if (!groups[category]) {
        groups[category] = { sum: 0, count: 0 };
      }
      groups[category].sum += numVal;
      groups[category].count++;
    }
  }

  return Object.entries(groups)
    .map(([name, stats]) => ({
      name,
      sum: parseFloat(stats.sum.toFixed(2)),
      average: parseFloat((stats.sum / stats.count).toFixed(2)),
      count: stats.count
    }))
    .sort((a, b) => b.sum - a.sum)
    .slice(0, 15);
}

/**
 * Runs time-series analysis on a date-like column vs numeric metric
 */
export function getTimeSeriesAnalysis(
  allRows: Record<string, any>[],
  dateCol: string,
  numCol: string
): { dateStr: string; value: number; rollingAvg: number }[] {
  const aggregates: Record<string, { sum: number; count: number; timestamp: number }> = {};

  for (const r of allRows) {
    const rawDate = r[dateCol];
    const numVal = Number(String(r[numCol]).replace(/[$,%]/g, ''));

    if (rawDate && !isNaN(numVal) && r[numCol] !== null) {
      const parsedTime = Date.parse(String(rawDate));
      if (!isNaN(parsedTime)) {
        // Format to YYYY-MM-DD
        const d = new Date(parsedTime);
        const dateStr = d.toISOString().split('T')[0];
        
        if (!aggregates[dateStr]) {
          aggregates[dateStr] = { sum: 0, count: 0, timestamp: parsedTime };
        }
        aggregates[dateStr].sum += numVal;
        aggregates[dateStr].count++;
      }
    }
  }

  // Sort chronological
  const sortedData = Object.entries(aggregates)
    .map(([dateStr, stat]) => ({
      dateStr,
      value: parseFloat((stat.sum / stat.count).toFixed(2)),
      timestamp: stat.timestamp
    }))
    .sort((a, b) => a.timestamp - b.timestamp);

  // Compute 5-point rolling average
  return sortedData.map((item, idx, arr) => {
    const windowSize = 5;
    const startIdx = Math.max(0, idx - Math.floor(windowSize / 2));
    const endIdx = Math.min(arr.length - 1, idx + Math.floor(windowSize / 2));
    
    let sum = 0;
    let count = 0;
    for (let i = startIdx; i <= endIdx; i++) {
      sum += arr[i].value;
      count++;
    }
    
    return {
      dateStr: item.dateStr,
      value: item.value,
      rollingAvg: parseFloat((sum / count).toFixed(2))
    };
  });
}
